const dashboardScriptIds = ['sb-launch', 'sb-version'];
const downloadBase = 'https://raw.githubusercontent.com/cwood315/sunshine-bay-extension-versions/main/';
const versionPattern = /^(0|[1-9]\d{0,4})(\.(0|[1-9]\d{0,4})){2}$/;
let versionCheck;
let versionCheckExpires = 0;

async function register(origin) {
  const registered = await chrome.scripting.getRegisteredContentScripts({ids: dashboardScriptIds});
  if (registered.length) {
    await chrome.scripting.unregisterContentScripts({ids: registered.map(script => script.id)});
  }
  if (!origin || !await chrome.permissions.contains({origins: [origin + '/*']})) return;

  const config = {matches: [origin + '/*'], runAt: 'document_idle', persistAcrossSessions: true};
  await chrome.scripting.registerContentScripts([
    {...config, id: 'sb-launch', js: ['dashboard.js'], world: 'MAIN'},
    {...config, id: 'sb-version', js: ['dashboard-version.js'], world: 'ISOLATED'}
  ]);
}

async function readVersionStatus() {
  const installed = chrome.runtime.getManifest().version;
  try {
    const response = await fetch(downloadBase + 'latest.json', {
      credentials: 'omit',
      redirect: 'error',
      referrerPolicy: 'no-referrer',
      signal: AbortSignal.timeout(4000)
    });
    if (!response.ok) return {installed};

    const {version} = await response.json();
    if (typeof version !== 'string' || !versionPattern.test(version)) return {installed};
    const latest = version.split('.').map(Number);
    if (latest.some(part => part > 65535)) return {installed};
    if (version === installed) return {installed, current: true};

    const installedParts = installed.split('.').map(Number);
    const difference = latest.map((part, index) => part - installedParts[index]).find(value => value !== 0);
    if (difference > 0) {
      return {
        installed,
        latest: version,
        downloadUrl: `${downloadBase}sunshine-bay-camera-dashboard-v${version}.zip`,
        releaseNotesUrl: `${downloadBase}release-notes-v${version}.txt`
      };
    }
  } catch {
    // The installed version remains available when the feed cannot be read.
  }
  return {installed};
}

function getVersionStatus() {
  if (Date.now() >= versionCheckExpires) {
    versionCheckExpires = Date.now() + 5 * 60 * 1000;
    versionCheck = readVersionStatus().then(status => {
      if (!status.current && !status.latest) versionCheckExpires = Date.now() + 30 * 1000;
      return status;
    });
  }
  return versionCheck;
}

async function downloadUpdate() {
  const {downloadUrl} = await getVersionStatus();
  if (!downloadUrl) return {error: 'No update is currently available.'};

  await chrome.downloads.download({url: downloadUrl});
  return {ok: true};
}

chrome.runtime.onInstalled.addListener(async () => register((await chrome.storage.local.get('origin')).origin));
chrome.runtime.onStartup.addListener(async () => register((await chrome.storage.local.get('origin')).origin));
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (message.type === 'register') {
    register(message.origin).then(() => reply({ok: true}), error => reply({error: String(error)}));
    return true;
  }
  if (message.type === 'getVersionStatus') {
    getVersionStatus().then(reply);
    return true;
  }
  if (message.type === 'downloadUpdate') {
    downloadUpdate().then(reply, () => reply({error: 'Chrome could not start the download.'}));
    return true;
  }
  if (message.type === 'openReleaseNotes') {
    getVersionStatus().then(async ({releaseNotesUrl}) => {
      if (!releaseNotesUrl) return {ok: false};
      await chrome.windows.create({url: releaseNotesUrl, type: 'popup', width: 720, height: 680});
      return {ok: true};
    }).then(reply, () => reply({ok: false}));
    return true;
  }
});
