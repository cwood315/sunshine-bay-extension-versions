(async()=>{const input=document.getElementById('address'),out=document.getElementById('result');input.value=(await chrome.storage.local.get('origin')).origin||'';document.getElementById('save').onclick=async()=>{try{const u=new URL(input.value.trim());if(!['http:','https:'].includes(u.protocol)||u.username||u.password)throw Error('Invalid address');const origin=u.origin;const ok=await chrome.permissions.request({origins:[origin+'/*']});if(!ok)throw Error('Site permission denied');const r=await chrome.runtime.sendMessage({type:'register',origin});if(r.error)throw Error(r.error);await chrome.storage.local.set({origin});out.textContent='Saved. Reload the e-Connect page after signing in.';}catch(e){out.textContent=e.message;}}})();
async function showAvailableUpdate() {
  const installed = chrome.runtime.getManifest().version;
  document.getElementById('installed-version').textContent = `Installed version ${installed}`;

  try {
    const status = await chrome.runtime.sendMessage({type: 'getVersionStatus'});
    if (status?.current) {
      document.getElementById('current-status').hidden = false;
      return;
    }

    if (!status?.latest) return;

    const notes = document.getElementById('update-version');
    notes.textContent = `v${status.latest}`;
    notes.href = status.releaseNotesUrl;
    notes.addEventListener('click', async event => {
      if (!event.isTrusted || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
      event.preventDefault();
      const feedback = document.getElementById('update-feedback');
      try {
        const result = await chrome.runtime.sendMessage({type: 'openReleaseNotes'});
        feedback.textContent = result?.ok ? '' : 'Chrome could not open the release notes.';
      } catch {
        feedback.textContent = 'Chrome could not open the release notes.';
      }
    });
    document.getElementById('download-link').href = status.downloadUrl;
    document.getElementById('update-notice').hidden = false;
  } catch {
    // Recorder setup remains available when the release feed cannot be read.
  }
}

showAvailableUpdate();
