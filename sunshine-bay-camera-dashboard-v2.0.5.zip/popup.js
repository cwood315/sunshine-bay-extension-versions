(async()=>{const input=document.getElementById('address'),out=document.getElementById('result');input.value=(await chrome.storage.local.get('origin')).origin||'';document.getElementById('save').onclick=async()=>{try{const u=new URL(input.value.trim());if(!['http:','https:'].includes(u.protocol)||u.username||u.password)throw Error('Invalid address');const origin=u.origin;const ok=await chrome.permissions.request({origins:[origin+'/*']});if(!ok)throw Error('Site permission denied');const r=await chrome.runtime.sendMessage({type:'register',origin});if(r.error)throw Error(r.error);await chrome.storage.local.set({origin});out.textContent='Saved. Reload the e-Connect page after signing in.';}catch(e){out.textContent=e.message;}}})();
const downloadBase = 'https://raw.githubusercontent.com/cwood315/sunshine-bay-extension-versions/main/';

async function showAvailableUpdate() {
  const installed = chrome.runtime.getManifest().version;
  document.getElementById('installed-version').textContent = `Installed version ${installed}`;

  try {
    const response = await fetch(downloadBase + 'latest.json', {
      credentials: 'omit',
      redirect: 'error',
      referrerPolicy: 'no-referrer',
      signal: AbortSignal.timeout(4000)
    });
    if (!response.ok) return;

    const {version} = await response.json();
    if (typeof version !== 'string' || !/^(0|[1-9]\d{0,4})(\.(0|[1-9]\d{0,4})){2}$/.test(version)) return;

    const latest = version.split('.').map(Number);
    if (latest.some(part => part > 65535)) return;
    const installedParts = installed.split('.').map(Number);
    const difference = latest.map((part, index) => part - installedParts[index]).find(value => value !== 0);
    if (!(difference > 0)) return;

    document.getElementById('update-version').textContent = `Update available · v${version}`;
    document.getElementById('download-link').href = `${downloadBase}sunshine-bay-camera-dashboard-v${version}.zip`;
    document.getElementById('update-notice').hidden = false;
  } catch {
    // Recorder setup remains available when the release feed cannot be read.
  }
}

showAvailableUpdate();
