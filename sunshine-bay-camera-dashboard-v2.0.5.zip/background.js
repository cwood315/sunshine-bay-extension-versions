async function register(origin){
 const old=await chrome.scripting.getRegisteredContentScripts();
 if(old.some(x=>x.id==='sb-launch')) await chrome.scripting.unregisterContentScripts({ids:['sb-launch']});
 if(origin && await chrome.permissions.contains({origins:[origin+'/*']}))
 await chrome.scripting.registerContentScripts([{id:'sb-launch',matches:[origin+'/*'],js:['dashboard.js'],runAt:'document_idle',world:'MAIN',persistAcrossSessions:true}]);
}
chrome.runtime.onInstalled.addListener(async()=>register((await chrome.storage.local.get('origin')).origin));
chrome.runtime.onStartup.addListener(async()=>register((await chrome.storage.local.get('origin')).origin));
chrome.runtime.onMessage.addListener((m,s,reply)=>{if(m.type==='register'){register(m.origin).then(()=>reply({ok:true}),e=>reply({error:String(e)}));return true;}});
