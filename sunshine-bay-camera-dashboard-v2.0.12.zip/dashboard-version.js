(() => {
  const installed = chrome.runtime.getManifest().version;

  async function showSurveillanceTeam(link) {
    const body = openExtensionDialog('SBC Surveillance Team', link);
    if (!body) return;
    body.textContent = 'Loading team photos…';
    try {
      const result = await chrome.runtime.sendMessage({type: 'getSurveillanceTeam'});
      if (result?.portraits?.length) {
        const grid = document.createElement('div');
        grid.style.cssText = 'display:grid;grid-template-columns:repeat(3,minmax(0,140px));gap:12px;justify-content:center;padding-top:6px';
        for (const {name, src} of result.portraits) {
          const figure = document.createElement('figure');
          figure.style.cssText = 'margin:0;text-align:center';
          if (src) {
            const image = document.createElement('img');
            image.src = src;
            image.alt = 'Portrait of ' + name;
            image.style.cssText = 'display:block;width:100%;aspect-ratio:1;object-fit:cover;border-radius:6px';
            figure.append(image);
          }
          const caption = document.createElement('figcaption');
          caption.style.marginTop = '6px';
          caption.textContent = name;
          figure.append(caption);
          grid.append(figure);
        }
        body.replaceChildren(grid);
        return;
      }
    } catch {
      // The extension may have been reloaded while the dashboard was open.
    }
    body.textContent = 'Team photos are unavailable. Close this dialog and try again.';
  }

  function connectTeamLink() {
    const link = document.getElementById('sb-surveillance-team-link');
    if (!link || !link.hidden) return;

    link.href = '#sbc-surveillance-team';
    link.onclick = event => {
      event.preventDefault();
      if (event.isTrusted) showSurveillanceTeam(link);
    };
    link.hidden = false;
  }

  async function renderVersionStatus() {
    const target = document.getElementById('sb-dashboard-version');
    if (!target) return;
    if (!target.firstChild) target.textContent = `v${installed}`;

    try {
      const status = await chrome.runtime.sendMessage({type: 'getVersionStatus'});
      if (!target.isConnected) return;
      target.textContent = `v${installed}`;

      if (status?.current) {
        const current = document.createElement('span');
        current.style.color = '#86efac';
        const dot = document.createElement('span');
        dot.setAttribute('aria-hidden', 'true');
        dot.style.cssText = 'display:inline-block;width:7px;height:7px;border-radius:50%;background:currentColor;margin:0 5px 1px 7px';
        current.append(dot, 'Up to date');
        target.append(current);
      } else if (status?.latest) {
        const update = document.createElement('div');
        const actionStyle = 'padding:0;border:0;background:none;color:#a9d9f2;font:inherit;text-decoration:underline;cursor:pointer';
        const notes = document.createElement('button');
        notes.type = 'button';
        notes.style.cssText = actionStyle;
        notes.setAttribute('aria-haspopup', 'dialog');
        notes.textContent = `v${status.latest}`;
        notes.title = 'View release notes';
        update.append('Update available · ', notes);
        const download = document.createElement('button');
        download.type = 'button';
        download.style.cssText = actionStyle;
        download.textContent = 'Download ZIP';
        const feedback = document.createElement('div');
        notes.addEventListener('click', event => {
          if (event.isTrusted) showExtensionReleaseNotes(notes);
        });
        download.addEventListener('click', async event => {
          if (!event.isTrusted || download.disabled) return;
          download.disabled = true;
          feedback.textContent = 'Starting download…';
          try {
            const result = await chrome.runtime.sendMessage({type: 'downloadUpdate'});
            feedback.textContent = result?.ok ? '' : result?.error || 'Chrome could not start the download.';
          } catch {
            feedback.textContent = 'Chrome could not start the download.';
          } finally {
            download.disabled = false;
          }
        });
        target.append(update, download, feedback);
      }
    } catch {
      // The installed version remains visible even if the worker is unavailable.
    }
  }

  // The dashboard runs in the page world, so the event carries no data.
  window.addEventListener('sb-dashboard-version-ready', () => {
    connectTeamLink();
    renderVersionStatus();
  });
  window.addEventListener('focus', renderVersionStatus);
  connectTeamLink();
  renderVersionStatus();
})();
