function openExtensionDialog(title, trigger) {
  const existing = document.getElementById('sb-extension-dialog');
  if (existing) return null;

  const dialog = document.createElement('dialog');
  dialog.id = 'sb-extension-dialog';
  dialog.setAttribute('aria-label', title);
  dialog.style.cssText = 'padding:0;background:#1d2d39;color:#f2f6fa;border:1px solid #557080;border-radius:12px;width:min(760px,calc(100% - 24px));max-width:none;max-height:calc(100vh - 24px);box-shadow:0 16px 70px #000a,0 0 0 100vmax #000c;font:14px Arial,sans-serif;box-sizing:border-box';

  const header = document.createElement('header');
  header.style.cssText = 'position:sticky;top:0;background:#1d2d39;display:flex;align-items:center;justify-content:space-between;gap:14px;padding:18px 22px;border-bottom:1px solid #405363';
  const heading = document.createElement('h2');
  heading.style.cssText = 'font-size:21px;margin:0';
  heading.textContent = title;
  const close = document.createElement('button');
  close.type = 'button';
  close.setAttribute('aria-label', 'Close ' + title);
  close.style.cssText = 'border:0;border-radius:5px;font-size:23px;padding:3px 11px;background:#405565;color:white;cursor:pointer;margin:0';
  close.textContent = '×';
  close.onclick = () => dialog.close();
  header.append(heading, close);

  const body = document.createElement('div');
  body.style.cssText = 'padding:12px 22px 22px;line-height:1.55';
  dialog.append(header, body);
  dialog.addEventListener('click', event => {
    if (event.target === dialog) dialog.close();
  });
  dialog.addEventListener('keydown', event => {
    if (event.key === 'Escape') event.stopPropagation();
  });
  dialog.addEventListener('close', () => {
    dialog.remove();
    trigger.focus();
  }, {once: true});
  document.body.append(dialog);
  dialog.showModal();
  close.focus();
  return body;
}

async function showExtensionReleaseNotes(trigger) {
  const body = openExtensionDialog('Release notes', trigger);
  if (!body) return;
  body.textContent = 'Loading release notes…';
  body.style.whiteSpace = 'pre-wrap';
  try {
    const result = await chrome.runtime.sendMessage({type: 'getReleaseNotes'});
    if (result?.text) {
      body.textContent = result.text;
      return;
    }
  } catch {
    // The extension may have been reloaded while the dashboard was open.
  }
  body.textContent = 'Release notes are unavailable. Close this dialog and try again.';
}
