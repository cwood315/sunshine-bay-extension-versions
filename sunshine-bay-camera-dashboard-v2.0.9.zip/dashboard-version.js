(() => {
  const installed = chrome.runtime.getManifest().version;

  async function renderVersionStatus() {
    const target = document.getElementById('sb-dashboard-version');
    if (!target) return;
    if (!target.firstChild) target.textContent = `v${installed}`;

    try {
      const status = await chrome.runtime.sendMessage({type: 'getVersionStatus'});
      if (!target.isConnected) return;
      target.textContent = `v${installed}`;

      if (status?.current) {
        const current = document.createElement('span');
        current.style.color = '#86efac';
        const dot = document.createElement('span');
        dot.setAttribute('aria-hidden', 'true');
        dot.style.cssText = 'display:inline-block;width:7px;height:7px;border-radius:50%;background:currentColor;margin:0 5px 1px 7px';
        current.append(dot, 'Up to date');
        target.append(current);
      } else if (status?.latest) {
        const update = document.createElement('div');
        update.textContent = `Update available · v${status.latest}`;
        const download = document.createElement('button');
        download.type = 'button';
        download.style.cssText = 'padding:0;border:0;background:none;color:#a9d9f2;font:inherit;text-decoration:underline;cursor:pointer';
        download.textContent = 'Download ZIP';
        const feedback = document.createElement('div');
        download.addEventListener('click', async event => {
          if (!event.isTrusted || download.disabled) return;
          download.disabled = true;
          feedback.textContent = 'Starting download…';
          try {
            const result = await chrome.runtime.sendMessage({type: 'downloadUpdate'});
            feedback.textContent = result?.ok ? '' : result?.error || 'Chrome could not start the download.';
          } catch {
            feedback.textContent = 'Chrome could not start the download.';
          } finally {
            download.disabled = false;
          }
        });
        target.append(update, download, feedback);
      }
    } catch {
      // The installed version remains visible even if the worker is unavailable.
    }
  }

  // The dashboard runs in the page world, so the event carries no data.
  window.addEventListener('sb-dashboard-version-ready', renderVersionStatus);
  window.addEventListener('focus', renderVersionStatus);
  renderVersionStatus();
})();
