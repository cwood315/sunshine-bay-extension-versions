(() => {
  if (window.__sunshineExtensionLoaded) return;
  window.__sunshineExtensionLoaded = true;
  const KEY='sunshineBayCameraDashboardV1';
  const ORDER_KEY='sunshineBayAllCamerasOrderV1';
  const VIEW_KEY='sunshineBayLastViewV1';
  const RETENTION_CACHE_KEY='sunshineBayRecordingHistoryCacheV1';
  const SHARED_RETENTION_ID='shared';
  const CHANNELS=[2,3,5,6,10,12,14,16,19,20,21];
  const TOP=.12, BOTTOM=.08, VISIBLE=1-TOP-BOTTOM;
  const DEFAULT_NAMES={"2": "4th Floor facing elevator", "3": "2nd Floor facing south", "5": "4th floor facing bay", "6": "Trash Room", "10": "2nd Floor facing north", "12": "Garage from NE corner", "14": "Garage from NW corner", "16": "Camera Room", "19": "Pedestrian Gate", "20": "Lobby facing north", "21": "Vehicle Ramp"};
  const defaults={groups:[{name:'Garage',cameras:[12,14,21,5]},{name:'Entries',cameras:[20,21,19,10]},{name:'Upper Floors',cameras:[2,3,10,5]},{name:'Trash/Camera Rooms',cameras:[16,6]}],names:{...DEFAULT_NAMES}};
  let settings;try{settings=JSON.parse(localStorage.getItem(KEY));if(!settings?.groups?.length)throw 0;settings.names ||= {};}catch{settings=structuredClone(defaults);}
  settings.groups=settings.groups.map((g,i)=>({name:String(g.name||`Group ${i+1}`),cameras:[...new Set((g.cameras||[]).map(Number).filter(ch=>CHANNELS.includes(ch)))].slice(0,4)}));
  let cameraOrder;
  try {
    const stored=JSON.parse(localStorage.getItem(ORDER_KEY));
    cameraOrder=[...new Set((Array.isArray(stored)?stored:[]).map(Number).filter(ch=>CHANNELS.includes(ch)))];
    cameraOrder.push(...CHANNELS.filter(ch=>!cameraOrder.includes(ch)));
  } catch { cameraOrder=[...CHANNELS]; }
  const saveOrder=()=>{try{localStorage.setItem(ORDER_KEY,JSON.stringify(cameraOrder));}catch(e){console.warn(e);}};
  const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(settings));}catch(e){console.warn(e);}};
  const make=(tag,css='',text='')=>{const x=document.createElement(tag);x.style.cssText=css;x.textContent=text;return x;};
  const btn=(s,fn)=>{const x=make('button','padding:9px 12px;border:0;border-radius:5px;background:#dceaf3;color:#12212b;cursor:pointer;font:inherit',s);x.onclick=fn;return x;};
  // Downloads are generated locally; no camera frames are sent to an outside server.
  const safeFilePart=value=>String(value).replace(/[^a-zA-Z0-9_-]+/g,'_').slice(0,55);
  function downloadBlob(blob,name){
    const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;
    document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
  }
  function snapshotCanvas(canvas,ch,epoch){
    try{
      if(!canvas.width||!canvas.height)throw Error('No video frame is available yet.');
      const stamp=miamiParts(new Date((epoch||Date.now()/1000)*1000));
      const name=`SunshineBay_${safeFilePart(settings.names[ch]||DEFAULT_NAMES[ch]||'Camera_'+ch)}_${stamp.day}_${stamp.time.replace(':','-')}_CH${ch}.png`;
      canvas.toBlob(blob=>{if(blob)downloadBlob(blob,name);else alert('Unable to capture this frame. The DVR canvas may not permit image export.');},'image/png');
    }catch(e){alert('Snapshot unavailable: '+e.message);}
  }

  let active=0,players=[],generation=0,closed=false,managing=false,modal=null,root=null,clockTimer=null;
  let allMode=false,selectedCamera=CHANNELS[0],allList=null,allFeed=null;
  let playbackDialog=null;
  try {
    const last=JSON.parse(localStorage.getItem(VIEW_KEY));
    if(last&&typeof last==='object'){
      if(Number.isInteger(last.group)&&last.group>=0&&last.group<settings.groups.length)active=last.group;
      if(CHANNELS.includes(last.camera))selectedCamera=last.camera;
      allMode=last.mode==='all';
    }
  }catch(e){console.warn('Unable to restore last camera view',e);}
  const saveView=()=>{
    try{localStorage.setItem(VIEW_KEY,JSON.stringify({mode:allMode?'all':'group',group:active,camera:selectedCamera}));}
    catch(e){console.warn('Unable to save camera view',e);}
  };
  const originalTitle=document.title;
  const wait=ms=>new Promise(r=>setTimeout(r,ms));
  const toggle=btn('Show Sunshine Bay',()=>open());
  toggle.style.cssText='position:fixed;right:18px;bottom:18px;z-index:2147483639;background:#17628c;color:white;border:1px solid #fff5;border-radius:9px;padding:12px 17px;box-shadow:0 4px 20px #0006;cursor:pointer;font:14px Arial';
  toggle.hidden=true;
  function closeModal(){
    if(!modal)return;
    const {overlay,tile,placeholder,wrapper,canvas,oldAspectRatio,oldTop}=modal;
    // Restore the original top/bottom crop when returning to the grid.
    if(wrapper)wrapper.style.aspectRatio=oldAspectRatio;
    if(canvas)canvas.style.top=oldTop;
    if(placeholder.parentNode)placeholder.replaceWith(tile);
    tile.style.width='';tile.style.position='';tile.style.boxShadow='';
    overlay.remove();modal=null;
  }
  function stop(){generation++;closeModal();closePlayback(false);for(const p of players){try{p.destroy();}catch(e){console.warn(e);}}players=[];}
  function hide(){closeGuide();stop();if(clockTimer)clearInterval(clockTimer);clockTimer=null;root?.remove();root=null;toggle.hidden=false;document.title=originalTitle;}
  function addTilePlaybackIcon(tile,ch){
    const label=tile.firstElementChild;
    if(!label)return;
    label.style.position='relative';
    const button=btn('▶',event=>{
      event.stopPropagation();
      openCamera(ch,'playback');
    });
    button.title='Play recordings for '+(settings.names[ch]||DEFAULT_NAMES[ch]||`Camera ${ch}`);
    button.setAttribute('aria-label',button.title);
    button.style.cssText='position:absolute;right:8px;top:50%;transform:translateY(-50%);width:30px;height:28px;padding:0;border:0;border-radius:5px;background:#80c9ed;color:#10202d;font:bold 15px Arial;line-height:28px;cursor:pointer;z-index:2';
    label.append(button);
  }
  // Both tile actions now open the same camera viewer in the requested mode.
  function enlarge(tile,ch){openCamera(ch,'live');}
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&playbackDialog&&!playbackDialog.inline)closePlayback();else if(e.key==='Escape'&&modal)closeModal();});
  let header,tabs,content,clock,actions,guideOverlay=null;
  function drawActions(){
    const guide=btn('❔ User Guide',showGuide);
    guide.title='How to use Sunshine Bay Cameras';
    const guideColumn=make('div','display:flex;flex-direction:column;align-items:flex-end;gap:5px');
    const versionStatus=make('div','font-size:12px;text-align:right;line-height:1.4;color:#b9d4e5');
    versionStatus.id='sb-dashboard-version';
    versionStatus.setAttribute('role','status');
    guideColumn.append(guide,versionStatus);
    actions.style.alignItems='flex-start';
    actions.replaceChildren(
      btn(managing?'Back to Cameras':'Manage Cameras',()=>managing?(allMode?showAllCameras():switchTab(active)):showManager()),
      btn('Show e-Connect',hide),
      guideColumn
    );
    window.dispatchEvent(new Event('sb-dashboard-version-ready'));
  }
  function closeGuide(){
    if(!guideOverlay)return;
    guideOverlay.remove();
    guideOverlay=null;
  }
  // A standalone reference page, opened from a direct user click. No DVR
  // address, session cookies, credentials, or live video are copied into it.
  function openTechnicalDetails(){
    const page=window.open('','_blank');
    if(!page){window.alert('Chrome blocked the new tab. Allow pop-ups for e-Connect and try again.');return;}
    try{
      page.opener=null;
      page.document.open();
      page.document.write(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sunshine Bay Cameras — Technical Details</title><style>
      :root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#101820;color:#e4edf3;font:15px/1.65 Arial,Helvetica,sans-serif}main{max-width:950px;margin:0 auto;padding:38px 26px 75px}h1{font-size:29px;line-height:1.2;margin:0 0 7px;color:#fff}h2{font-size:20px;color:#a9d9f2;margin:32px 0 10px;border-bottom:1px solid #405363;padding-bottom:6px}h3{font-size:16px;color:#c9e6f6;margin:17px 0 6px}p,li{margin:7px 0}ul,ol{padding-left:25px}code{font-family:Consolas,monospace;background:#263b49;border-radius:4px;padding:2px 5px;overflow-wrap:anywhere}pre{background:#172530;padding:14px;border:1px solid #405363;border-radius:7px;overflow-x:auto}pre code{padding:0;background:transparent}a{color:#80c9ed}.muted{color:#a9bfcd;font-size:12px}.note{border-left:3px solid #80c9ed;padding:8px 14px;background:#1b2d3a;border-radius:4px}table{border-collapse:collapse;width:100%}th,td{border-bottom:1px solid #405363;padding:9px;text-align:left;vertical-align:top}th{color:#a9d9f2}@media(max-width:600px){main{padding:24px 16px}h1{font-size:24px}}
      </style></head><body><main>
      <h1>Sunshine Bay Cameras — Technical Details</h1><div class="muted">Extension version 2.0.3 · Implementation reference</div>
      <p>This document describes the implementation in this extension release. It is not documentation for the EPCOM recorder firmware, and internal recorder APIs may change.</p>
      <h2>1. Architecture and installation</h2>
      <p>The dashboard is a Chrome Manifest V3 extension. Its <code>popup.html</code> and <code>popup.js</code> let the user enter the e-Connect website address. <code>background.js</code> requests host permission for that origin and registers <code>dashboard.js</code> as a persistent content script, running at <code>document_idle</code> in the page's <code>MAIN</code> JavaScript world.</p>
      <p>Running in the MAIN world is intentional: the script can access the recorder page's existing <code>window.requirejs</code> modules. The dashboard overlays the authenticated e-Connect page, rather than operating as a separate video server. It depends on the user being signed in to e-Connect.</p>
      <p class="note">The extension does not store DVR credentials in its own settings or send recordings to a separate Sunshine Bay server. It uses the browser's existing recorder session. Because it executes in the page's JavaScript world, it is not isolated from other scripts on that page.</p>
      <h2>2. Camera configuration and navigation</h2>
      <p>Eleven channels are configured: <code>2, 3, 5, 6, 10, 12, 14, 16, 19, 20, 21</code>. Four default groups are defined in the script: Garage, Entries, Upper Floors, and Trash/Camera Rooms. Group membership is configurable, with up to four cameras per group.</p>
      <p>The All Cameras view retains a reorderable camera list on the left and a single selected camera viewer on the right. The viewer is embedded in the page, not displayed in a modal. Selecting a different camera tears down the previous stream before starting the new one. Group views use a two-column grid of up to four live streams; selecting a tile opens the unified Live/Playback modal. Group Playback is a separate multi-camera viewer.</p>
      <h2>3. Live video</h2>
      <p>The script loads <code>WasmPlayer/wasm-player</code> through the recorder page's <code>requirejs</code> loader. It creates a <code>Player</code> with <code>type:'live'</code> and an HTML <code>canvas</code>, waits for the WebAssembly decoder to be ready, then calls <code>player.play</code> with a channel identifier, <code>streamType:2</code>, and <code>audio:false</code>.</p>
      <p>Channel identifiers use a recorder-specific GUID-like format. The numeric channel is converted to eight hexadecimal digits and inserted into the first field, e.g. channel 21 becomes <code>{00000015-0000-0000-0000-000000000000}</code>.</p>
      <p>Each stream has success and error handlers, a loading indicator, and cleanup via <code>player.destroy()</code>. A generation counter prevents stale asynchronous operations from updating a view after the user has switched cameras. Each group live tile has a lower-left snapshot shortcut; the All Cameras viewer also supports one-click snapshots.</p>
      <h2>4. Recorded playback</h2>
      <p>The same WebAssembly player is initialized with <code>type:'record'</code>. Playback supplies a channel ID, name, Unix-epoch start/end timestamps, <code>streamType:1</code>, and a canvas destination. The <code>ontime</code> callback provides the recording position used to update the visible clock and timeline.</p>
      <p>Controls call the player's available methods, including <code>pause()</code>, <code>resume()</code>, <code>seek()</code>, and <code>setSpeed()</code>. The default date and time are calculated when playback opens as <strong>five minutes before the current time</strong>, formatted for <code>America/New_York</code> (Miami local time). Recording history is searched once for the DVR and cached as a shared date for 24 hours. Subsequent checks search near the previously observed oldest date. Both single-camera and group playback date pickers use the shared oldest date. Individual cameras may occasionally have different recording availability.</p>
      <p>The shared earliest-recording lookup is stored in browser <code>localStorage</code> and used to set the minimum date on playback date pickers when a verified result exists. The UI displays <strong>Earliest recording: [date]</strong>. This is a DVR-wide convenience assumption, not proof that every camera has footage on that date or at every time.</p>
      <p>Switching between Live and Playback replaces the active player. The All Cameras viewer keeps its controls in the right pane; the group tile viewer uses a popup. The popup is anchored near the top of the viewport to avoid jumping between modes.</p>
      <h2>5. Recording and motion activity</h2>
      <p>The extension calls the e-Connect <code>Communication</code> module's <code>queryChlRecLog</code> request using recorder-formatted XML. Results are parsed from the returned <code>recList</code> and converted into segments on the selected date.</p>
      <table><thead><tr><th>Timeline color</th><th>Meaning</th></tr></thead><tbody><tr><td>Blue</td><td>Scheduled/available recording segments</td></tr><tr><td>Yellow</td><td>Motion-triggered recording segments</td></tr></tbody></table>
      <p>Clicking a timeline position seeks to the corresponding recording time. Previous/Next Motion searches the available motion segments; zoom controls adjust the displayed time range. Activity reflects what the DVR reports and may not cover gaps or unavailable footage.</p>
      <h2>6. Synchronized group playback</h2>
      <p>Group Playback creates up to four independent recorded players, one for each camera in the selected group. A shared date/time selector and transport controls initiate playback, seeking, pausing, skipping, and speed changes across those players. Each camera has its own recording/motion activity row, with a common time reference. Previous/Next Motion can navigate across all cameras' events.</p>
      <p>Decoder initialization is staggered to reduce load. Every three seconds, the extension compares the most recently reported playback timestamps against the first camera reporting a timestamp. If a camera differs by more than three seconds, it attempts to seek that camera to the reference time.</p>
      <p class="note">This is best-effort synchronization, not frame-accurate or forensic synchronization. Actual accuracy depends on recorder timestamps, decoder behavior, network conditions, and whether the player supports seeking at that moment.</p>
      <h2>7. Snapshots and video clip export</h2>
      <p><strong>Snapshots:</strong> Individual Live and Playback viewers save the current canvas frame as a PNG using <code>canvas.toBlob()</code>. Group live tiles provide a lower-left camera shortcut for immediate capture. Group Playback provides a lower-left snapshot icon on each camera feed and <strong>Snapshot All</strong>, which draws the available frames into a composite canvas and downloads a PNG. Captures can fail if a canvas is unavailable or the browser prevents export.</p>
      <p><strong>Video clips:</strong> Single-camera Playback has a <strong>Save Clip</strong> panel, while each Group Playback camera has a lower-left clip icon that opens the shared clip panel. Users select a Miami-local date and start/end times, or mark the current position. The extension seeks to the requested start and records the playback canvas with <code>canvas.captureStream(15)</code> and the browser's <code>MediaRecorder</code>, using a supported WebM codec (VP9 or VP8 when available). The result is a silent <code>.webm</code> download, with a maximum selected duration of ten minutes.</p>
      <p>Clip capture occurs locally in the browser at playback speed; it is not a native DVR file export. In Group Playback, exporting a clip from one camera seeks the group to the clip start to maintain the common time reference. Recording depends on browser codec support, canvas access, continuous playback, and keeping the viewer open until completion. Cancel discards the incomplete clip.</p>
      <p class="note">Browser-generated screenshots and clips are convenient for incident review, but should not be treated as authenticated or forensic-quality originals. Preserve original DVR footage when evidentiary integrity is important.</p>
      <h2>8. Settings and persistence</h2>
      <p>The configured e-Connect origin is stored using Chrome extension <code>chrome.storage.local</code>. Dashboard preferences are stored separately in the e-Connect page's browser <code>localStorage</code>:</p>
      <ul><li><code>sunshineBayCameraDashboardV1</code> — camera names and groups</li><li><code>sunshineBayAllCamerasOrderV1</code> — sidebar camera order</li><li><code>sunshineBayLastViewV1</code> — last group or All Cameras selection</li><li><code>sunshineBayRecordingHistoryCacheV1</code> — shared oldest-observed recording date and lookup metadata, refreshed approximately every 24 hours</li></ul>
      <p>These preferences are browser/profile-specific, not shared across board members. Clearing site data or changing browser profiles can reset them.</p>
      <h2>9. Lifecycle and performance</h2>
      <p>Changing groups or cameras calls cleanup routines that destroy old players, close viewers, and invalidate pending asynchronous work. The group grid is capped at four simultaneous streams because recorder/browser connection and decoder resources are limited. Group playback also uses up to four players. The dashboard clock updates once per second and uses Miami local time.</p>
      <h2>10. Troubleshooting and limitations</h2>
      <ul><li><strong>No streams:</strong> Verify e-Connect is signed in, the extension has site permission, and the page has finished loading. Refresh the recorder page if needed.</li><li><strong>Decoder unavailable:</strong> The recorder's WebAssembly player may not be ready or compatible; reload and retry.</li><li><strong>Recording gaps:</strong> Not every channel necessarily has footage for every time. The DVR's recording log is the source of available activity.</li><li><strong>Group playback drift:</strong> Sync corrections are periodic and depend on the recorder player implementation.</li><li><strong>Interface changes:</strong> Updates to e-Connect's internal <code>requirejs</code> modules or XML protocol could require extension updates.</li><li><strong>Snapshot fails:</strong> The canvas may not be ready or may prohibit image export.</li><li><strong>Clip fails or is incomplete:</strong> Check browser WebM/MediaRecorder support, keep the viewer open, and confirm continuous DVR playback. Clip capture is not a native DVR export.</li><li><strong>Oldest date:</strong> The shared retention boundary is inferred from a DVR search and may not reflect gaps or differences between individual cameras.</li></ul>
      <h2>11. Source files</h2>
      <table><thead><tr><th>File</th><th>Purpose</th></tr></thead><tbody><tr><td><code>manifest.json</code></td><td>MV3 extension metadata and permissions</td></tr><tr><td><code>background.js</code></td><td>Host-specific script registration</td></tr><tr><td><code>popup.html</code> / <code>popup.js</code></td><td>Recorder origin setup</td></tr><tr><td><code>dashboard.js</code></td><td>Dashboard UI, video players, motion queries, and synchronization</td></tr><tr><td><code>README.txt</code></td><td>Installation and usage notes</td></tr></tbody></table>
      <p class="muted">This page was generated locally by the installed extension. It contains no live DVR data or credentials.</p>
      </main></body></html>`);
      page.document.close();
    }catch(e){console.warn('Could not open technical details',e);page.close();window.alert('Unable to open the technical reference page.');}
  }
  function showGuide(){
    if(!root||guideOverlay)return;
    guideOverlay=make('div',
      'position:fixed;inset:0;z-index:2147483647;background:#000c;display:flex;align-items:center;justify-content:center;padding:16px;box-sizing:border-box');
    guideOverlay.setAttribute('role','dialog');
    guideOverlay.setAttribute('aria-modal','true');
    guideOverlay.setAttribute('aria-label','Sunshine Bay Cameras user guide');
    const panel=make('div',
      'background:#1d2d39;color:#f2f6fa;border:1px solid #557080;border-radius:12px;width:min(760px,100%);max-height:90vh;display:flex;flex-direction:column;box-shadow:0 16px 70px #000a;overflow:hidden');
    const top=make('div',
      'display:flex;align-items:center;justify-content:space-between;gap:14px;padding:18px 22px;border-bottom:1px solid #405363');
    const guideHeading=make('div','display:flex;flex-direction:column;gap:4px');
    guideHeading.append(make('h2','font-size:21px;margin:0','Sunshine Bay Cameras — User Guide'));
    guideHeading.append(make('div','font-size:11px;color:#a9bfcd;line-height:1.2','Version 2.0.3'));
    top.append(guideHeading);
    const x=btn('×',closeGuide);
    x.setAttribute('aria-label','Close user guide');
    x.style.cssText='font-size:23px;padding:3px 11px;background:#405565;color:white';
    top.append(x);
    const body=make('div','overflow-y:auto;padding:8px 22px 22px;line-height:1.55');
    const section=(title,paragraphs)=>{
      const h=make('h3','font-size:16px;color:#a9d9f2;margin:20px 0 7px',title);
      body.append(h);
      for(const text of paragraphs)body.append(make('p','margin:0 0 9px;color:#e4edf3',text));
    };
    section('Getting started',[
      'Open the e-Connect recorder webpage in Chrome and sign in as usual. The Sunshine Bay dashboard opens automatically once the camera player is ready.',
      'The dashboard uses your existing e-Connect session. It does not change camera settings or recordings.'
    ]);
    section('Synchronized group playback',[
      'Choose a camera group, then select Group Playback just above the camera feeds. All cameras in the group share the same date, time, transport controls, and playback playhead.',
      'The recording activity display has a separate row for each camera: blue indicates recording and yellow indicates motion. Click anywhere on a row to seek every camera to that time. Previous/Next Motion searches across the group.',
      'The DVR supplies independent recordings, so the dashboard periodically attempts to correct timestamp drift. Some cameras may have gaps, and simultaneous playback depends on DVR connection capacity.'
    ]);
    section('Camera groups',[
      'Choose a group using the buttons along the top. Each group displays up to four live feeds. Switching groups disconnects the previous streams, so new cameras may take a moment to appear.',
      'Click the small camera icon at the lower left of any live feed to save a snapshot without opening the enlarged viewer.',
      'Default groups: Garage (12, 14, 21, 5); Entries (20, 21, 19, 10); Upper Floors (2, 3, 10, 5); Trash/Camera Rooms (16, 6).'
    ]);
    section('All Cameras',[
      'Select All Cameras to view one camera at a time. Choose a camera from the left-hand list; its Live/Playback viewer appears directly on the right, with no popup.',
      'Use the ↑ and ↓ buttons beside a camera to change its position in the list. Reset order restores numerical channel order. Your order is saved automatically.'
    ]);
    section('Enlarging a camera',[
      'Click a live camera tile to open a larger view. Unlike the smaller tiles, this view shows the full image, including the DVR’s camera label and timestamp.',
      'Click ×, click outside the enlarged image, or press Esc to close it. The live stream continues without restarting.'
    ]);
    section('Snapshots and video clips',[
      'Click Snapshot in a Live or Playback viewer to download a PNG of the displayed frame. Group Playback has a camera icon at the lower left of each feed for a snapshot, plus Snapshot All for a combined image.',
      'In single-camera Playback or Group Playback, click Save Clip to choose a Miami date, start time, and end time. In Group Playback, click the scissors icon at the lower left of a feed to save that camera’s clip; exporting one camera seeks the shared group to the clip start. Mark Start and Mark End can copy the current playback position. Record & Download Clip captures the replay locally as a silent WebM video.',
      'Video export uses the browser canvas rather than the DVR’s original file. It records at playback speed and may fail if the DVR canvas is protected or recording is interrupted. Clips are limited to ten minutes. Keep the viewer open until download completes.'
    ]);
    section('Recorded playback',[
      'Click a camera to open its combined Live / Playback viewer, or click the ▶ icon on a tile to open the same viewer directly in Playback mode. Choose a Miami date and time and click Play from selected time.',
      'Use Pause/Resume, speeds up to 32×, and skip controls. The activity timeline shows DVR recording in blue and motion events in yellow. Click to seek, zoom in, or use Previous/Next Motion.',
      'Use Go Live to switch back to live footage in the same viewer. Closing the viewer restores the dashboard camera feeds. Only one viewer stream is active at a time.'
    ]);
    section('Manage Cameras',[
      'Select Manage Cameras to rename groups, add or delete groups, rearrange their order, and edit camera names. Check the groups in which each camera should appear.',
      'A group may contain up to four cameras; a camera can appear in multiple groups. Changes are saved automatically.',
      'Restore Default Groups restores the four original groups and their assignments after confirmation. It keeps your custom camera names and All Cameras list order.'
    ]);
    section('Switching to e-Connect',[
      'Click Show e-Connect to return to the original recorder interface. Use the floating Show Sunshine Bay button to return to this dashboard.'
    ]);
    section('Saved preferences',[
      'Your camera names, groups, All Cameras order, and last selected group or individual camera are saved in this browser. Each board member can customize their own dashboard independently.'
    ]);
    section('If a camera does not load',[
      'Allow a few seconds for the stream to connect. Try selecting another camera or group, or refresh the e-Connect webpage and sign in again if needed.',
      'The recorder currently supports up to four simultaneous dashboard streams. Click any camera to switch between Live and Playback in one viewer. The viewer temporarily stops the dashboard grid streams.'
    ]);
    const technicalHeading=make('h3','font-size:16px;color:#a9d9f2;margin:22px 0 7px','Technical Details');
    const technicalIntro=make('p','margin:0 0 9px;color:#e4edf3','For architecture, DVR integration, playback synchronization, data storage, and troubleshooting, see the technical reference.');
    const technicalLink=make('button','background:transparent;border:0;padding:0;color:#80c9ed;font:inherit;font-weight:bold;text-decoration:underline;cursor:pointer;text-align:left','Open Technical Details in a new tab ↗');
    technicalLink.onclick=openTechnicalDetails;
    body.append(technicalHeading,technicalIntro,technicalLink);
    panel.append(top,body);
    guideOverlay.append(panel);
    guideOverlay.addEventListener('click',e=>{if(e.target===guideOverlay)closeGuide();});
    root.append(guideOverlay);
    x.focus();
  }
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&guideOverlay){e.stopPropagation();closeGuide();}});

  function drawTabs(){
    tabs.replaceChildren();if(managing)return;
    const all=btn('All Cameras',()=>showAllCameras());
    if(allMode)all.style.background='#80c9ed';
    tabs.append(all);
    settings.groups.forEach((g,i)=>{
      const b=btn(`${g.name} (${g.cameras.length})`,()=>switchTab(i));
      if(!allMode&&i===active)b.style.background='#80c9ed';
      tabs.append(b);
    });
  }
  function open(){
    if(root)return;
    toggle.hidden=true;closed=false;document.title='SBC Cameras';
    root=make('div','position:fixed;inset:0;z-index:2147483640;background:#101820;color:#f2f6fa;font:14px Arial;overflow:auto;padding:20px;box-sizing:border-box');
    header=make('div','display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:18px');
    header.append(make('h2','margin:0','Sunshine Bay | Security Cameras'));
    actions=make('div','display:flex;gap:8px');header.append(actions);
    tabs=make('div','display:flex;gap:8px;flex-wrap:wrap;margin-bottom:15px');
    clock=make('div','text-align:right;color:#dceaf3;font-size:15px;margin-bottom:12px;font-variant-numeric:tabular-nums');
    content=make('div');
    const footer=make('footer','margin-top:auto;padding-top:16px;text-align:right');
    const teamLink=make('a','color:#a9d9f2;text-decoration:underline','SBC Surveillance Team');
    teamLink.id='sb-surveillance-team-link';
    teamLink.hidden=true;
    footer.append(teamLink);
    const aligned=make('div','display:flex;flex-direction:column;min-height:100%;width:100%;max-width:1500px;margin:0 auto;box-sizing:border-box');
    aligned.append(header,tabs,clock,content,footer);
    root.append(aligned);document.body.append(root);
    const fmt=new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',month:'2-digit',day:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true});
    const update=()=>clock.textContent=fmt.format(new Date()).replace(/\u202f/g,' ').replace(/\b(AM|PM)\b/g,s=>s.toLowerCase());
    update();clockTimer=setInterval(update,1000);
    if(allMode)showAllCameras();else switchTab(active);
  }
  async function switchTab(index){if(!root||!settings.groups[index])return;managing=false;allMode=false;stop();const token=generation;active=index;saveView();drawActions();drawTabs();content.replaceChildren();const grid=make('div','display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;max-width:1500px;margin:auto');const groupToolbar=make('div','display:flex;justify-content:flex-end;align-items:center;max-width:1500px;margin:0 auto 10px');const groupPlaybackButton=btn('▶ Group Playback',()=>openGroupPlayback(active));groupPlaybackButton.title='Play recordings from all cameras in this group on one timeline';groupToolbar.append(groupPlaybackButton);content.append(groupToolbar,grid);const feeds=settings.groups[index].cameras.slice(0,4).map(ch=>{const name=()=>settings.names[ch]||DEFAULT_NAMES[ch]||`Camera ${ch}`;const tile=make('div','background:black;border:1px solid #405363;border-radius:7px;overflow:hidden;cursor:pointer;min-width:0');const label=make('div','padding:10px 48px 10px 12px;background:#243442;color:white',`${name()} (CH ${ch})`);const wrapper=make('div',`position:relative;width:100%;aspect-ratio:640 / ${360*VISIBLE};overflow:hidden;background:black`);const canvas=make('canvas',`display:block;width:100%;height:auto;position:absolute;top:${-TOP/VISIBLE*100}%;left:0;visibility:hidden`);canvas.width=640;canvas.height=360;const loader=make('div','position:absolute;inset:0;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:10px;color:#9bb4c5;font-size:12px;pointer-events:none');const spinner=make('div','width:22px;height:22px;border:2px solid #344a59;border-top-color:#80c9ed;border-radius:50%;animation:sbSpin 1s linear infinite');const msg=make('div','','Waiting for stream…');loader.append(spinner,msg);wrapper.append(canvas,loader);
      // Quick snapshot for each group live tile. Keep the tile click-to-enlarge
      // behavior intact by stopping propagation only for this control.
      const quickSnapshot=btn('📷',event=>{
        event.stopPropagation();
        if(canvas.style.visibility!=='visible'){
          alert('Please wait until this camera is streaming before taking a snapshot.');
          return;
        }
        snapshotCanvas(canvas,ch,null);
      });
      quickSnapshot.title='Save snapshot of '+name();
      quickSnapshot.setAttribute('aria-label',quickSnapshot.title);
      quickSnapshot.style.cssText='position:absolute;left:8px;bottom:8px;z-index:3;width:32px;height:30px;padding:0;border:1px solid #7897ab;border-radius:5px;background:#243442e8;color:white;font:18px Arial;line-height:28px;cursor:pointer;box-sizing:border-box';
      wrapper.append(quickSnapshot);
      tile.append(label,wrapper);addTilePlaybackIcon(tile,ch);grid.append(tile);tile.onclick=()=>enlarge(tile,ch);return {ch,name,label,canvas,loader,spinner,msg};});if(!document.getElementById('sb-animation')){const st=make('style','','@keyframes sbSpin{to{transform:rotate(360deg)}}');st.id='sb-animation';root.append(st);}await new Promise(r=>setTimeout(r,1500));if(!root||token!==generation)return;const Player=window.requirejs?.('WasmPlayer/wasm-player');if(!Player){feeds.forEach(f=>{f.spinner.style.display='none';f.msg.textContent='Player unavailable';});return;}for(const f of feeds){if(!root||token!==generation)return;f.msg.textContent='Connecting…';try{const player=new Player({type:'live',canvas:f.canvas,onsuccess:()=>{if(token!==generation||!root)return;f.canvas.style.visibility='visible';f.loader.style.display='none';f.label.firstChild.textContent=`${f.name()} (CH ${f.ch}) — Streaming`;},onerror:e=>{if(token!==generation||!root)return;f.spinner.style.display='none';f.msg.textContent='Connection unavailable';console.warn('Camera',f.ch,e);}});players.push(player);for(let i=0;i<50&&!player.wasmReady&&token===generation;i++)await new Promise(r=>setTimeout(r,100));if(token!==generation||!root)return;if(!player.wasmReady){f.spinner.style.display='none';f.msg.textContent='Decoder unavailable';continue;}const id=f.ch.toString(16).toUpperCase().padStart(8,'0');player.play({chlID:`{${id}-0000-0000-0000-000000000000}`,streamType:2,audio:false});}catch(e){f.spinner.style.display='none';f.msg.textContent='Connection error';console.warn(e);}await new Promise(r=>setTimeout(r,500));}}

  // All Cameras: a single stream with a reorderable camera list.
  // Changing cameras destroys the old stream before opening the next.
  function showAllCameras() {
    if(!root)return;
    managing=false;allMode=true;
    saveView();
    stop();
    drawActions();drawTabs();content.replaceChildren();

    const layout=make('div',
      'display:grid;grid-template-columns:minmax(205px,260px) minmax(0,1fr);gap:14px;align-items:start');
    const sidebar=make('div',
      'background:#1d2d39;border:1px solid #405363;border-radius:8px;overflow:hidden');
    const heading=make('div',
      'padding:12px;background:#243442;display:flex;justify-content:space-between;align-items:center;gap:8px');
    heading.append(make('strong','','Cameras'));
    const reset=btn('Reset order',()=>{
      cameraOrder=[...CHANNELS];saveOrder();drawCameraList();
    });
    reset.style.cssText+=';padding:5px 8px;font-size:11px';
    heading.append(reset);
    sidebar.append(heading);
    allList=make('div','max-height:calc(100vh - 235px);overflow-y:auto');
    sidebar.append(allList);

    allFeed=make('div','min-width:0');
    layout.append(sidebar,allFeed);
    content.append(layout);

    drawCameraList();
    selectSingleCamera(selectedCamera);
  }

  function drawCameraList() {
    if(!allList)return;
    allList.replaceChildren();
    cameraOrder.forEach((ch,i)=>{
      const row=make('div',
        'display:flex;align-items:center;gap:5px;padding:5px 7px;border-bottom:1px solid #405363');
      if(ch===selectedCamera)row.style.background='#31546b';
      const name=settings.names[ch]||DEFAULT_NAMES[ch]||`Camera ${ch}`;
      const select=btn(`${name} (CH ${ch})`,()=>selectSingleCamera(ch));
      select.title=`View ${name}`;
      select.style.cssText=
        'flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:left;'+
        'padding:8px 6px;border:0;border-radius:4px;background:transparent;color:#f2f6fa;cursor:pointer;font:inherit';
      const move=(label,delta)=>{
        const b=btn(label,()=>{
          const j=i+delta;
          if(j<0||j>=cameraOrder.length)return;
          [cameraOrder[i],cameraOrder[j]]=[cameraOrder[j],cameraOrder[i]];
          saveOrder();drawCameraList();
        });
        b.title=delta<0?'Move up':'Move down';
        b.setAttribute('aria-label',`${delta<0?'Move up':'Move down'} ${name}`);
        b.style.cssText='padding:3px 6px;background:#344a59;color:#f2f6fa;border:0;border-radius:4px;cursor:pointer';
        if(i+delta<0||i+delta>=cameraOrder.length){b.disabled=true;b.style.opacity='.3';}
        return b;
      };
      row.append(select,move('↑',-1),move('↓',1));
      allList.append(row);
    });
  }

  // All Cameras keeps the existing left-hand camera list and hosts the
  // unified single-camera Live/Playback player directly in the right pane.
  function selectSingleCamera(ch) {
    if(!root||!allMode||!CHANNELS.includes(ch))return;
    selectedCamera=ch;
    saveView();
    drawCameraList();
    openCamera(ch,'live',allFeed);
  }
  // Recorded playback uses the DVR's existing WebAssembly player.
  // We close all live players first to respect the DVR connection limit.
  function closePlayback(restore=true){
    const d=playbackDialog;
    if(!d)return;
    playbackDialog=null;
    d.closed=true;
    d.activityRequest++;
    try{d.activityObserver?.disconnect();}catch(e){}
    try{d.cancelClip?.();}catch(e){}
    try{d.player?.destroy();}catch(e){console.warn('Playback cleanup',e);}
    if(d.groupPlayers)for(const player of d.groupPlayers){try{player?.destroy();}catch(e){console.warn('Group playback cleanup',e);}}
    if(d.syncTimer)clearInterval(d.syncTimer);
    d.overlay.remove();
    if(restore&&root&&!managing){if(allMode)selectSingleCamera(selectedCamera);else switchTab(active);}
  }
  function miamiParts(date){
    const parts=new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(date);
    const obj=Object.fromEntries(parts.map(x=>[x.type,x.value]));
    return {day:`${obj.year}-${obj.month}-${obj.day}`,time:`${obj.hour}:${obj.minute}`,seconds:Number(obj.hour)*3600+Number(obj.minute)*60+Number(obj.second)};
  }
  function miamiEpoch(day,time){
    const [y,m,d]=day.split('-').map(Number),[hh,mm]=time.split(':').map(Number);
    if(!y||!m||!d||!Number.isFinite(hh)||!Number.isFinite(mm))return NaN;
    const desired=Date.UTC(y,m-1,d,hh,mm);
    let ms=desired;
    for(let i=0;i<4;i++){
      const p=miamiParts(new Date(ms));
      const [py,pm,pd]=p.day.split('-').map(Number),[ph,pmin]=p.time.split(':').map(Number);
      const actual=Date.UTC(py,pm-1,pd,ph,pmin);
      const delta=desired-actual;
      ms+=delta;
      if(!delta)break;
    }
    return Math.floor(ms/1000);
  }
  function formatRecordingTime(value){
    const n=Number(value);
    if(!Number.isFinite(n))return String(value);
    const d=new Date(n>1e12?n:n*1000);
    return Number.isNaN(d.getTime())?String(value):new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',month:'2-digit',day:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true}).format(d);
  }
  async function openCamera(ch,initialMode='playback',inlineHost=null){
    if(!root||!CHANNELS.includes(ch))return;
    // stop() tears down live feeds, including the enlarged view.
    stop();
    const token=generation;
    const overlay=make('div',inlineHost?'position:relative;width:100%;min-width:0;box-sizing:border-box':'position:fixed;inset:0;z-index:2147483646;background:#000e;display:flex;align-items:flex-start;justify-content:center;padding:14px;box-sizing:border-box;overflow-y:auto');
    const panel=make('div',inlineHost?'width:100%;background:#172530;border:1px solid #496071;border-radius:12px;padding:12px;box-sizing:border-box;color:#f2f6fa;min-width:0':'width:min(1100px,96vw);max-height:96vh;overflow:auto;background:#172530;border:1px solid #496071;border-radius:12px;padding:15px;box-sizing:border-box;color:#f2f6fa;box-shadow:0 14px 60px #000a');
    const top=make('div','display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:10px');
    top.append(make('strong','font-size:18px',`${settings.names[ch]||DEFAULT_NAMES[ch]||`Camera ${ch}`} (CH ${ch})`));
    const exit=btn('×',()=>closePlayback());
    exit.title='Close camera viewer';exit.setAttribute('aria-label','Close camera viewer');
    exit.style.cssText='width:30px;height:30px;padding:0;border:0;border-radius:5px;background:#405565;color:white;font:bold 19px Arial;cursor:pointer';
    if(!inlineHost)top.append(exit);
    panel.append(top);
    const modeBar=make('div','display:flex;gap:8px;margin-bottom:10px');
    const liveButton=btn('● Live',()=>switchMode('live'));
    const playbackButton=btn('▶ Playback',()=>switchMode('playback'));
    modeBar.append(liveButton,playbackButton);panel.append(modeBar);
    const goLive=btn('● Go Live',()=>switchMode('live'));
    goLive.style.marginLeft='auto';

    const canvas=make('canvas','display:block;width:100%;height:auto;aspect-ratio:16/9;background:#000;border-radius:6px');
    canvas.width=960;canvas.height=540;panel.append(canvas);
    const status=make('div','padding:10px 0;color:#b9d4e5;font-variant-numeric:tabular-nums','Select a date and time, then press Play.');panel.append(status);
    const captureRow=make('div','display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:8px 0');
    const snap=btn('📷 Snapshot',()=>snapshotCanvas(canvas,ch,state.mode==='playback'?state.lastTime:null));
    const clipToggle=btn('✂ Save Clip',()=>{if(state.mode!=='playback'){switchMode('playback');}clipPanel.hidden=!clipPanel.hidden;});
    captureRow.append(snap,clipToggle);panel.append(captureRow);
    const clipPanel=make('div','background:#20313d;border:1px solid #496071;border-radius:7px;padding:12px;margin:8px 0');
    clipPanel.hidden=true;
    const clipInputs=make('div','display:flex;gap:9px;align-items:center;flex-wrap:wrap;margin:8px 0');
    const clipDay=make('input','padding:6px;border-radius:5px');clipDay.type='date';
    const clipStart=make('input','padding:6px;border-radius:5px');clipStart.type='time';clipStart.step='1';
    const clipEnd=make('input','padding:6px;border-radius:5px');clipEnd.type='time';clipEnd.step='1';
    const markStart=btn('Mark Start',()=>{const p=miamiParts(new Date((state.lastTime||miamiEpoch(date.value,time.value))*1000));clipDay.value=p.day;clipStart.value=`${p.time}:${String(p.seconds%60).padStart(2,'0')}`;});
    const markEnd=btn('Mark End',()=>{const p=miamiParts(new Date((state.lastTime||miamiEpoch(date.value,time.value))*1000));clipDay.value=p.day;clipEnd.value=`${p.time}:${String(p.seconds%60).padStart(2,'0')}`;});
    const exportButton=btn('⬇ Record & Download Clip',()=>exportClip());
    const cancelButton=btn('Cancel',()=>{
      if(state.clip){cancelClip();clipInfo.textContent='Clip recording canceled.';}
      else{clipPanel.hidden=true;}
    });
    const clipActions=make('div','display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-top:10px');
    clipActions.append(markStart,markEnd,exportButton,cancelButton);
    for(const button of [markStart,markEnd,exportButton,cancelButton]){
      button.style.setProperty('height','36px','important');
      button.style.setProperty('box-sizing','border-box','important');
      button.style.setProperty('display','inline-flex','important');
      button.style.setProperty('align-items','center','important');
      button.style.setProperty('justify-content','center','important');
      button.style.setProperty('align-self','center','important');
      button.style.setProperty('margin','0','important');
      button.style.setProperty('padding','0 12px','important');
      button.style.setProperty('line-height','1','important');
      button.style.setProperty('white-space','nowrap','important');
      button.style.setProperty('flex-shrink','0','important');
    }
    const clipInfo=make('div','font-size:12px;color:#b9d4e5;margin-top:7px','Browser export records the displayed playback in real time as a silent WebM video. Keep this viewer open until the download finishes.');
    clipInputs.append(make('span','','Date:'),clipDay,make('span','','Start:'),clipStart,make('span','','End:'),clipEnd);
    clipPanel.append(make('strong','','Individual camera video clip'),clipInputs,clipActions,clipInfo);panel.append(clipPanel);
    const clipDefault=miamiParts(new Date(Date.now()-5*60000));clipDay.value=clipDefault.day;clipStart.value=clipDefault.time+':00';
    clipEnd.value=miamiParts(new Date(Date.now())).time+':00';

    const playbackElements=[];
    const controls=make('div','display:flex;gap:9px;flex-wrap:wrap;align-items:center;margin:8px 0');
    const now=miamiParts(new Date(Date.now()-5*60*1000));
    const date=make('input','padding:8px;border-radius:5px');date.type='date';date.value=now.day;date.max=now.day;date.min='';
    const time=make('input','padding:8px;border-radius:5px');time.type='time';time.value=now.time;time.step=60;
    const play=btn('▶ Play from selected time',()=>{state.motionJumpAnchor=null;startAtSelected();});
    const dateLabel=make('span','','Date (Miami):');
    const timeLabel=make('span','','Time:');
    // Group each label with its input so external e-Connect CSS cannot
    // shift the buttons relative to the date/time controls.
    const dateGroup=make('div','display:inline-flex;align-items:center;gap:6px;flex:0 0 auto;white-space:nowrap');
    const timeGroup=make('div','display:inline-flex;align-items:center;gap:6px;flex:0 0 auto;white-space:nowrap');
    dateGroup.append(dateLabel,date);
    timeGroup.append(timeLabel,time);
    controls.append(dateGroup,timeGroup,play,goLive);
    // Keep the original v1.1.6 single-row layout, but prevent the DVR page's
    // CSS from collapsing the space between labels, inputs and buttons.
    controls.style.setProperty('display','flex','important');
    controls.style.setProperty('flex-wrap','nowrap','important');
    controls.style.setProperty('overflow-x','auto','important');
    controls.style.setProperty('overflow-y','hidden','important');
    controls.style.setProperty('padding','3px 2px','important');
    controls.style.setProperty('column-gap','12px','important');
    controls.style.setProperty('row-gap','8px','important');
    controls.style.setProperty('align-items','center','important');
    for(const group of [dateGroup,timeGroup]){
      group.style.setProperty('display','inline-flex','important');
      group.style.setProperty('align-items','center','important');
      group.style.setProperty('gap','6px','important');
      group.style.setProperty('height','36px','important');
      group.style.setProperty('flex-shrink','0','important');
      group.style.setProperty('margin','0','important');
    }
    for(const label of [dateLabel,timeLabel]){
      label.style.setProperty('display','inline-flex','important');
      label.style.setProperty('align-items','center','important');
      label.style.setProperty('height','36px','important');
      label.style.setProperty('white-space','nowrap','important');
      label.style.setProperty('flex-shrink','0','important');
      label.style.setProperty('margin','0','important');
    }
    // A little breathing room before the Time label.
    timeLabel.style.setProperty('margin-left','5px','important');
    for(const field of [date,time]){
      field.style.setProperty('margin-right','0','important');
      field.style.setProperty('flex-shrink','0','important');
    }
    panel.append(controls);playbackElements.push(controls);
    const retentionInfo=make('div','font-size:12px;color:#b9d4e5;margin:-2px 0 8px','Checking oldest available recording…');panel.append(retentionInfo);playbackElements.push(retentionInfo);
    const bar=make('div','display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:10px 0');
    const pause=btn('⏸ Pause',()=>{
      if(!state.player)return;
      try{if(state.paused){state.player.resume();pause.textContent='⏸ Pause';}else{state.player.pause();pause.textContent='▶ Resume';}state.paused=!state.paused;}
      catch(e){status.textContent='Pause/resume failed: '+e.message;}
    });
    const back=btn('↶ 30 sec',()=>skip(-30));const forward=btn('30 sec ↷',()=>skip(30));
    const speed=make('select','padding:8px;border-radius:5px');
    for(const value of ['0.5','1','2','4','8','16','32']){const opt=make('option','',`${value}×`);opt.value=value;speed.append(opt);}speed.value='1';
    speed.onchange=()=>{try{state.player?.setSpeed(Number(speed.value));}catch(e){status.textContent='Playback speed not supported: '+e.message;}};
    // Align controls without changing the original v1.1.6 layout.
    // e-Connect's own styles can collapse flex gaps, so give each control
    // an explicit right margin as well as a consistent height.
    for(const control of [play,goLive,back,pause,forward,speed]){
      control.style.setProperty('height','35px','important');
      control.style.setProperty('box-sizing','border-box','important');
      control.style.setProperty('vertical-align','middle','important');
      control.style.setProperty('align-self','center','important');
      control.style.setProperty('margin-top','0','important');
      control.style.setProperty('margin-bottom','0','important');
      control.style.setProperty('margin-right','5px','important');
      control.style.setProperty('flex-shrink','0','important');
    }
    for(const button of [play,goLive,back,pause,forward]){
      button.style.setProperty('display','inline-flex','important');
      button.style.setProperty('align-items','center','important');
      button.style.setProperty('justify-content','center','important');
      button.style.setProperty('white-space','nowrap','important');
      button.style.setProperty('line-height','1','important');
      button.style.setProperty('padding','0 12px','important');
    }
    // Match the optical vertical alignment of the native date/time inputs.
    for(const button of [play,goLive]){
      button.style.setProperty('position','relative','important');
      button.style.setProperty('top','-1px','important');
    }
    // Override the original auto margin only for Go Live, to prevent
    // the button drifting away from Play in the original flex row.
    // Extra separation between the Time field and Play, without altering the row layout.
    play.style.setProperty('margin-left','18px','important');
    goLive.style.setProperty('margin-left','0','important');
    for(const button of [play,goLive]){
      button.style.setProperty('position','relative','important');
      button.style.setProperty('top','-1px','important');
      button.style.setProperty('transform','none','important');
      button.style.setProperty('min-height','35px','important');
    }
    for(const field of [date,time]){
      field.style.setProperty('height','36px','important');
      field.style.setProperty('box-sizing','border-box','important');
      field.style.setProperty('align-self','center','important');
      field.style.setProperty('margin','0','important');
    }
    bar.append(back,pause,forward,make('span','','Speed:'),speed);panel.append(bar);playbackElements.push(bar);
    // DVR-backed activity timeline: blue = scheduled recording, yellow = motion.
    const activityBox=make('div','margin:12px 0 8px;background:#20313d;border:1px solid #496071;border-radius:8px;padding:10px');
    const activityHeader=make('div','display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:8px');
    const activityTitle=make('strong','font-size:13px','Recording activity');
    const activityInfo=make('span','font-size:12px;color:#b9d4e5','Loading activity…');
    const zoomSelect=make('select','padding:5px;border-radius:5px;margin-left:auto');
    for(const hours of [24,12,6,3,1]){const option=make('option','',hours===24?'Full day':`${hours} hour${hours===1?'':'s'}`);option.value=String(hours);zoomSelect.append(option);}
    activityHeader.append(activityTitle,activityInfo,make('span','font-size:12px','Zoom:'),zoomSelect);
    const activityCanvas=make('canvas','display:block;width:100%;height:72px;background:#263846;border-radius:5px;cursor:pointer;touch-action:pan-y');
    activityCanvas.height=72;
    const legend=make('div','display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-top:8px;font-size:12px;color:#c4d5df');
    const blue=make('span','','■ Recording');blue.style.color='#0080FF';
    const yellow=make('span','','■ Motion');yellow.style.color='#fefc0b';
    const pointer=make('span','','│ Playback position');pointer.style.color='#f4f7fa';
    legend.append(blue,yellow,pointer);
    const eventControls=make('div','display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:10px');
    const prevMotion=btn('← Previous Motion',()=>jumpMotion(-1));
    const nextMotion=btn('Next Motion →',()=>jumpMotion(1));
    const centerTime=btn('Center on playback',()=>{state.viewCenter=state.currentSeconds;drawActivity();});
    eventControls.append(prevMotion,nextMotion,centerTime);
    activityBox.append(activityHeader,activityCanvas,legend,eventControls);
    panel.append(activityBox);playbackElements.push(activityBox);
    const timelineRow=make('div','display:flex;gap:12px;align-items:center;margin:12px 0');
    const timeline=make('input','flex:1;min-width:120px');timeline.type='range';timeline.min='0';timeline.max='86399';timeline.step='1';timeline.value=String(now.seconds);
    const timelineLabel=make('span','min-width:85px;font-variant-numeric:tabular-nums',now.time);
    timeline.oninput=()=>{const n=Number(timeline.value);timelineLabel.textContent=secondsLabel(n);state.currentSeconds=n;drawActivity();};
    timeline.onchange=()=>{state.motionJumpAnchor=null;time.value=secondsLabel(Number(timeline.value)).slice(0,5);startAtSelected(Number(timeline.value));};
    timelineRow.append(make('span','','12 AM'),timeline,timelineLabel,make('span','','11:59 PM'));panel.append(timelineRow);playbackElements.push(timelineRow);
    const activityHelp=make('div','font-size:12px;color:#a8c0cf','Click the colored timeline to jump to a recording. Zoom in for individual motion events. Activity is retrieved from the DVR for the selected camera and date.');panel.append(activityHelp);playbackElements.push(activityHelp);
    overlay.append(panel);
    if(inlineHost)inlineHost.replaceChildren(overlay);else root.append(overlay);
    const state={overlay,player:null,closed:false,paused:false,lastTime:null,request:0,activityRequest:0,records:[],currentSeconds:now.seconds,viewCenter:now.seconds,motionJumpAnchor:null,clip:null,mode:null};
    state.inline=!!inlineHost;
    playbackDialog=state;
    // Modal closes only through its explicit X button; backdrop clicks do nothing.
    const id=ch.toString(16).toUpperCase().padStart(8,'0');
    const channelID=`{${id}-0000-0000-0000-000000000000}`;
    function secondsLabel(n){
      n=Math.max(0,Math.min(86399,Math.floor(Number(n)||0)));
      return `${String(Math.floor(n/3600)).padStart(2,'0')}:${String(Math.floor(n%3600/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
    }
    function visibleRange(){
      const duration=Number(zoomSelect.value||24)*3600;
      const start=duration>=86400?0:Math.max(0,Math.min(86400-duration,state.viewCenter-duration/2));
      return {start,end:start+duration,duration};
    }
    function drawActivity(){
      if(state.closed)return;
      const width=Math.max(300,Math.round(activityCanvas.getBoundingClientRect().width||750));
      const ratio=Math.min(window.devicePixelRatio||1,2);
      activityCanvas.width=Math.round(width*ratio);activityCanvas.height=Math.round(72*ratio);
      const ctx=activityCanvas.getContext('2d');ctx.scale(ratio,ratio);
      const left=12,right=width-12,plotWidth=right-left;
      const {start,end,duration}=visibleRange();
      ctx.fillStyle='#263846';ctx.fillRect(0,0,width,72);
      ctx.fillStyle='#14232e';ctx.fillRect(left,10,plotWidth,29);
      const segments=state.records;
      for(const type of ['SCHEDULE','MOTION']){
        ctx.fillStyle=type==='MOTION'?'#fefc0b':'#0080FF';
        for(const rec of segments){
          if(rec.event!==type||rec.endTime<start||rec.startTime>end)continue;
          const a=left+(Math.max(start,rec.startTime)-start)/duration*plotWidth;
          const b=left+(Math.min(end,rec.endTime)-start)/duration*plotWidth;
          ctx.fillRect(a,13,Math.max(1,b-a),23);
        }
      }
      ctx.strokeStyle='#8297a5';ctx.fillStyle='#d2e0e8';ctx.font='11px sans-serif';
      const step=duration>=86400?4*3600:duration>=43200?2*3600:duration>=21600?3600:duration>=10800?1800:duration>=3600?900:300;
      for(let t=Math.ceil(start/step)*step;t<=end;t+=step){
        const x=left+(t-start)/duration*plotWidth;
        ctx.beginPath();ctx.moveTo(x,41);ctx.lineTo(x,46);ctx.stroke();
        ctx.textAlign=t===0?'left':t>=86400?'right':'center';ctx.fillText(secondsLabel(t).slice(0,5),x,60);
      }
      if(state.currentSeconds>=start&&state.currentSeconds<=end){
        const x=left+(state.currentSeconds-start)/duration*plotWidth;
        ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x,5);ctx.lineTo(x,40);ctx.stroke();
      }
    }
    function jumpMotion(direction){
      const motions=state.records.filter(r=>r.event==='MOTION').sort((a,b)=>a.startTime-b.startTime);
      // Keep the last selected event as the navigation anchor. The DVR's ontime
      // callback can report an earlier timestamp while a seek reconnects.
      const current=state.motionJumpAnchor===null?state.currentSeconds:state.motionJumpAnchor;
      const event=direction>0?motions.find(r=>r.startTime>current+1):motions.filter(r=>r.startTime<current-1).pop();
      if(!event){activityInfo.textContent=direction>0?'No later motion event today.':'No earlier motion event today.';return;}
      state.motionJumpAnchor=event.startTime;state.currentSeconds=event.startTime;state.viewCenter=event.startTime;
      time.value=secondsLabel(event.startTime).slice(0,5);timeline.value=String(event.startTime);
      timelineLabel.textContent=secondsLabel(event.startTime);drawActivity();startAtSelected(event.startTime);
    }
    activityCanvas.onclick=e=>{
      const rect=activityCanvas.getBoundingClientRect();const x=e.clientX-rect.left;
      const left=12,right=rect.width-12;if(x<left||x>right)return;
      const {start,duration}=visibleRange();
      const seconds=Math.min(86399,Math.max(0,Math.round(start+(x-left)/(right-left)*duration)));
      state.motionJumpAnchor=null;state.currentSeconds=seconds;state.viewCenter=seconds;
      time.value=secondsLabel(seconds).slice(0,5);timeline.value=String(seconds);
      timelineLabel.textContent=secondsLabel(seconds);drawActivity();startAtSelected();
    };
    zoomSelect.onchange=()=>{state.viewCenter=state.currentSeconds;drawActivity();};
    date.onchange=()=>{state.motionJumpAnchor=null;if(date.value<date.min)date.value=date.min;if(date.value>date.max)date.value=date.max;state.records=[];state.viewCenter=state.currentSeconds;drawActivity();loadActivity();};
    // Share the exact working motion-timeline query for both activity and
    // retention. The DVR can reject overlapping queryChlRecLog requests.
    let recordingQueryTail=Promise.resolve();
    function recordingXml(Communication,day){
      return Communication.GetRequestHeader('queryChlRecLog')+
        '<types><recType><enum>MOTION</enum><enum>SCHEDULE</enum><enum>SENSOR</enum><enum>MANUAL</enum><enum>INTELLIGENT</enum><enum>POS</enum></recType></types>'+
        '<requireField><chl/><recList><item><recType/><startTime/><endTime/><size/></item></recList></requireField>'+
        `<condition><startTime>${day} 00:00:00</startTime><endTime>${day} 23:59:59</endTime>`+
        "<recType type='list'><itemType type='recType'/><item>MOTION</item><item>SCHEDULE</item></recType>"+
        `<chl id='${channelID}'></chl></condition>`+Communication.GetRequestEnd();
    }
    function queryRecordingDay(Communication,day){
      const run=()=>new Promise((resolve,reject)=>Communication.Request({url:'queryChlRecLog',data:recordingXml(Communication,day)}).done(resolve).fail(reject));
      const pending=recordingQueryTail.then(run);
      recordingQueryTail=pending.then(()=>{},()=>{});
      return pending;
    }
    async function loadActivity(){
      const request=++state.activityRequest;
      state.records=[];drawActivity();activityInfo.textContent='Loading activity…';
      let Communication;
      try{Communication=window.requirejs('Communication');}catch(e){activityInfo.textContent='Recording search unavailable';return;}
      const day=date.value;
      if(!/^\d{4}-\d{2}-\d{2}$/.test(day)){activityInfo.textContent='Choose a date';return;}
      try{
        const result=await new Promise((resolve,reject)=>queryRecordingDay(Communication,day).then(resolve,reject));
        if(state.closed||request!==state.activityRequest||day!==date.value)return;
        const $=window.jQuery;
        const responseStatus=$('response>status',result).text();
        if(responseStatus!=='success'){
          activityInfo.textContent='Activity unavailable: '+($('response>errorDescription',result).text()||responseStatus);
          return;
        }
        const parsed=[];
        $('response>content>recList>item',result).each(function(){
          const node=$(this),event=node.find('recType').text();
          if(event!=='MOTION'&&event!=='SCHEDULE')return;
          const toSeconds=str=>{
            const match=String(str).match(/(\d{2}):(\d{2}):(\d{2})/);
            return match?Number(match[1])*3600+Number(match[2])*60+Number(match[3]):NaN;
          };
          const startTime=toSeconds(node.find('startTime').text());
          const endTime=toSeconds(node.find('endTime').text());
          if(Number.isFinite(startTime)&&Number.isFinite(endTime)&&endTime>=startTime)parsed.push({event,startTime,endTime});
        });
        state.records=parsed;
        const motionCount=parsed.filter(r=>r.event==='MOTION').length;
        activityInfo.textContent=`${motionCount} motion events · ${parsed.filter(r=>r.event==='SCHEDULE').length} recording segments`;
        drawActivity();
      }catch(e){if(!state.closed&&request===state.activityRequest){activityInfo.textContent='Could not load recording activity';console.warn('SBC recording search',e);}}
    }
    // The DVR accepts the same single-day query used by the motion timeline.
    // Multi-day queries can return errorParam, so never use them for retention.
    // This is a best-effort search for the oldest observed recording, NOT a
    // guaranteed retention boundary: isolated older footage may still exist.
    async function findOldestRecording(){
      // Cache each camera's oldest observed recording. A full historical scan
      // is necessary only for a camera without a valid cached result.
      const DAY=86400000, MAX_AGE=24*60*60*1000;
      // Build calendar dates from numeric components rather than Date.parse.
      // The previous strict parsing could reject the current date on some DVR
      // browser environments, preventing even a valid cached result from loading.
      const parseDay=day=>{
        const match=/^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(String(day||''));
        if(!match)return NaN;
        const year=Number(match[1]),month=Number(match[2]),dayNum=Number(match[3]);
        if(year<2020||year>2100||month<1||month>12||dayNum<1||dayNum>31)return NaN;
        const ms=Date.UTC(year,month-1,dayNum);
        const checked=new Date(ms);
        return checked.getUTCFullYear()===year&&checked.getUTCMonth()===month-1&&checked.getUTCDate()===dayNum?ms:NaN;
      };
      const nowDate=new Date();
      let todayMiami='';
      try{todayMiami=miamiParts(nowDate).day;}catch(e){console.info('SBC Miami calendar lookup',e);}
      let today=parseDay(todayMiami);
      const earliestAllowed=Date.UTC(2020,0,1);
      if(!Number.isFinite(today)||today<earliestAllowed){
        // Fall back to the browser's current calendar date; never send a
        // nonsensical 1969/1970 search to the DVR.
        today=Date.UTC(nowDate.getFullYear(),nowDate.getMonth(),nowDate.getDate());
        console.info('SBC retention: Miami date unavailable, using local calendar date',todayMiami);
      }
      if(!Number.isFinite(today)||today<earliestAllowed){
        retentionInfo.textContent='Recording history search unavailable: browser date could not be determined. Date selection remains unrestricted.';
        return;
      }
      const dayAt=ms=>Number.isFinite(ms)&&ms>=earliestAllowed&&ms<=today?new Date(ms).toISOString().slice(0,10):null;
      const cacheId=SHARED_RETENTION_ID;
      let cache={};
      try{const stored=JSON.parse(localStorage.getItem(RETENTION_CACHE_KEY));if(stored&&typeof stored==='object'&&!Array.isArray(stored))cache=stored;}catch{}
      // Migrate the previously verified Camera 12 result to the shared cache.
      // Other cameras appear to use the same recorder retention policy.
      if(!cache[cacheId]&&cache['12']&&dayAt(parseDay(cache['12'].oldest))){
        cache[cacheId]=cache['12'];
        try{localStorage.setItem(RETENTION_CACHE_KEY,JSON.stringify(cache));}catch{}
      }
      const previous=cache[cacheId];
      const cachedDay=previous&&dayAt(parseDay(previous.oldest));
      const cachedAt=Number(previous?.checkedAt);
      const isFresh=!!cachedDay&&Number.isFinite(cachedAt)&&cachedAt<=Date.now()&&Date.now()-cachedAt<MAX_AGE;
      // Only apply a date boundary after a valid per-camera result exists.
      // The cache is refreshed independently; never use a guessed date.
      const applyOldestLimit=day=>{
        if(state.closed||!day||!dayAt(parseDay(day)))return;
        date.min=day;
        if(date.value<day){date.value=day;state.motionJumpAnchor=null;state.records=[];loadActivity();}
      };
      const showResult=(day,note)=>{
        const label=new Date(day+'T12:00:00Z').toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric',timeZone:'UTC'});
        retentionInfo.textContent='Earliest recording: '+label;
        applyOldestLimit(day);
      };
      if(cachedDay){showResult(cachedDay,isFresh?'cached, checked within 24 hours':'cached, refreshing in background');}
      if(isFresh)return;
      // Avoid duplicate DVR scans when multiple viewers are opened together.
      if(window.__sbcSharedRetentionScan){
        try{await window.__sbcSharedRetentionScan;}catch{}
        if(state.closed)return;
        try{const updated=JSON.parse(localStorage.getItem(RETENTION_CACHE_KEY)||'{}')[cacheId];
          if(updated&&dayAt(parseDay(updated.oldest)))showResult(updated.oldest,'shared');}catch{}
        return;
      }
      let Communication;
      try{Communication=window.requirejs('Communication');}
      catch(e){if(!cachedDay&&!state.closed)retentionInfo.textContent='Recording history search unavailable. Date selection remains unrestricted.';return;}
      const $=window.jQuery;
      let scanned=0;
      async function scanDay(day){
        if(state.closed)return null;
        const result=await queryRecordingDay(Communication,day);
        if(state.closed)return null;
        const status=$('response>status',result).text().trim();
        const description=$('response>errorDescription',result).text().trim();
        scanned++;
        if(status==='noRecord'||description==='noRecord')return false;
        if(status!=='success')throw Error('Recording search rejected for '+day+': '+(description||status||'unknown response'));
        return $('response>content>recList>item',result).length>0;
      }
      const scanTask=(async()=>{
      try{
        let oldest=cachedDay||null;
        if(cachedDay){
          // Recheck near the known boundary, rather than searching from today.
          // Look a few days earlier in case previously unseen footage appears.
          const anchor=parseDay(cachedDay);
          for(let n=3;n>=1;n--){
            const d=dayAt(anchor-n*DAY);if(!d)continue;
            if(await scanDay(d))oldest=d;
          }
          // Overwrite retention normally moves forward. Check the cached day
          // and walk forward until a recorded day is found (bounded work).
          const stillPresent=await scanDay(cachedDay);
          if(stillPresent){if(!oldest)oldest=cachedDay;}
          else{
            oldest=null;
            for(let n=1;n<=14;n++){
              const d=dayAt(anchor+n*DAY);if(!d)break;
              if(await scanDay(d)){oldest=d;break;}
            }
          }
          // If the boundary has moved farther than 14 days, keep the prior
          // observation, but do not incorrectly mark it as freshly verified.
          if(!oldest){
            if(!state.closed)retentionInfo.textContent='Earliest recording: '+new Date(cachedDay+'T12:00:00Z').toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric',timeZone:'UTC'});
            return;
          }
        }else{
          // First lookup only: scan backwards from today. All later sessions
          // use the persisted per-camera result instead of repeating this.
          let foundAny=false,emptyDays=0;
          for(let offset=0;offset<180;offset++){
            if(state.closed)return;
            const d=dayAt(today-offset*DAY);if(!d)break;
            const found=await scanDay(d);
            if(found){foundAny=true;emptyDays=0;oldest=d;}
            else if(foundAny)emptyDays++;
            if(offset%7===0&&!state.closed)retentionInfo.textContent='Checking recording history… '+scanned+' days searched';
            if(foundAny&&emptyDays>=21)break;
          }
        }
        if(state.closed)return;
        if(oldest){
          cache[cacheId]={oldest,checkedAt:Date.now()};
          try{localStorage.setItem(RETENTION_CACHE_KEY,JSON.stringify(cache));}catch(e){console.info('SBC retention cache unavailable',e);}
          showResult(oldest,scanned+' days checked; updated today');
        }else retentionInfo.textContent='Recording history unavailable.';
      }catch(e){
        if(state.closed)return;
        if(cachedDay){
          showResult(cachedDay,'cached');
        }else{
          retentionInfo.textContent='Recording history diagnostic: '+e.message+' ('+scanned+' successful day searches). Date selection remains unrestricted.';
        }
        console.info('SBC retention lookup stopped:',e.message);
      }
      })();
      window.__sbcSharedRetentionScan=scanTask;
      try{await scanTask;}finally{if(window.__sbcSharedRetentionScan===scanTask)window.__sbcSharedRetentionScan=null;}
    }
    if(window.ResizeObserver){const observer=new ResizeObserver(()=>drawActivity());observer.observe(activityCanvas);state.activityObserver=observer;}
    drawActivity();
    function updateTimeline(timestamp){
      const n=Number(timestamp);if(!Number.isFinite(n))return;
      const dt=new Date(n>1e12?n:n*1000);if(Number.isNaN(dt.getTime()))return;
      const p=miamiParts(dt);
      if(p.day===date.value){state.currentSeconds=p.seconds;timeline.value=String(p.seconds);timelineLabel.textContent=secondsLabel(p.seconds);drawActivity();}
    }
    function skip(seconds){
      state.motionJumpAnchor=null;
      const base=state.lastTime??miamiEpoch(date.value,time.value);
      if(!Number.isFinite(base))return;
      const dt=new Date((base+seconds)*1000);const p=miamiParts(dt);
      if(p.day<date.min||p.day>date.max){status.textContent='No recordings outside the available date range.';return;}
      const dateChanged=date.value!==p.day;date.value=p.day;time.value=p.time;
      state.currentSeconds=p.seconds;state.viewCenter=p.seconds;drawActivity();if(dateChanged)loadActivity();
      startAtSelected(p.seconds);
    }
    state.cancelClip=()=>cancelClip();
    function cancelClip(){
      const clip=state.clip;if(!clip)return;
      state.clip=null;
      try{clearTimeout(clip.timeout);clip.recorder?.stop();}catch(e){}
      try{clip.stream?.getTracks().forEach(t=>t.stop());}catch(e){}
      exportButton.disabled=false;
    }
    async function exportClip(){
      if(state.clip){clipInfo.textContent='A clip is already being recorded.';return;}
      if(!window.MediaRecorder||!canvas.captureStream){clipInfo.textContent='Video export is not supported by this Chrome/browser configuration.';return;}
      const day=clipDay.value,startStr=clipStart.value,endStr=clipEnd.value;
      if(!day||!startStr||!endStr){clipInfo.textContent='Enter the date, start time and end time.';return;}
      const start=miamiEpoch(day,startStr)+Number(startStr.split(':')[2]||0);
      const end=miamiEpoch(day,endStr)+Number(endStr.split(':')[2]||0);
      if(!Number.isFinite(start)||!Number.isFinite(end)||end<=start){clipInfo.textContent='End time must be later than start time on the selected date.';return;}
      if(end-start>600){clipInfo.textContent='For browser export, select a clip of 10 minutes or less.';return;}
      if(end>Date.now()/1000){clipInfo.textContent='The clip cannot end in the future.';return;}
      const mime=['video/webm;codecs=vp9','video/webm;codecs=vp8','video/webm'].find(x=>MediaRecorder.isTypeSupported(x));
      if(!mime){clipInfo.textContent='This browser does not support WebM recording.';return;}
      try{
        // Reuse the existing authenticated DVR playback connection; do not fabricate an MP4.
        cancelClip();exportButton.disabled=true;
        const stream=canvas.captureStream(15);
        const recorder=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:2500000});
        const clip={start,end,stream,recorder,chunks:[],started:false,finished:false};state.clip=clip;
        recorder.ondataavailable=e=>{if(e.data?.size)clip.chunks.push(e.data);};
        recorder.onerror=e=>{clipInfo.textContent='Video encoding failed: '+(e.error?.message||'unknown error');cancelClip();};
        recorder.onstop=()=>{
          stream.getTracks().forEach(t=>t.stop());
          if(state.clip===clip)state.clip=null;
          exportButton.disabled=false;
          if(!clip.finished){clipInfo.textContent='Clip export canceled or interrupted.';return;}
          if(!clip.chunks.length){clipInfo.textContent='No video frames were captured.';return;}
          const file=`SunshineBay_${safeFilePart(settings.names[ch]||DEFAULT_NAMES[ch]||'Camera_'+ch)}_${day}_${startStr.replace(/:/g,'-')}_CH${ch}.webm`;
          downloadBlob(new Blob(clip.chunks,{type:mime}),file);
          clipInfo.textContent='Video clip downloaded as WebM (no audio).';
        };
        date.value=day;time.value=startStr.slice(0,5);speed.value='1';
        clipInfo.textContent='Seeking to clip start; recording will begin when DVR frames arrive…';
        await startAtSelected(Number(startStr.split(':')[2]||0));
        if(state.clip!==clip)return;
        // Start capture after a short decoder warm-up. DVR timestamps determine the end.
        await wait(800);
        if(state.clip!==clip||state.closed)return;
        recorder.start(1000);clip.started=true;
        clipInfo.textContent='Recording clip in real time. Keep this viewer open…';
        // Safety timeout if the recorder stops reporting timestamps.
        clip.timeout=setTimeout(()=>{if(state.clip===clip){clipInfo.textContent='Clip timed out waiting for DVR playback.';cancelClip();}},Math.min(900000,(end-start+90)*1000));
      }catch(e){clipInfo.textContent='Could not export video: '+e.message;cancelClip();}
    }
    async function startAtSelected(exactSeconds=null){
      if(state.closed||!root||token!==generation)return;
      if(date.value<date.min||date.value>date.max){status.textContent='Selected date is outside the available recording range.';return;}
      const start=miamiEpoch(date.value,time.value)+(exactSeconds===null?0:Math.max(0,Math.min(59,Math.floor(exactSeconds)%60)));
      if(!Number.isFinite(start)){status.textContent='Please select a valid date and time.';return;}
      const end=miamiEpoch(date.value,'23:59')+59;
      if(start>end){status.textContent='Invalid playback time.';return;}
      state.currentSeconds=miamiParts(new Date(start*1000)).seconds;state.viewCenter=state.currentSeconds;drawActivity();
      if(state.clip&&state.clip.started)cancelClip();
      const request=++state.request;
      try{state.player?.destroy();}catch(e){console.warn(e);}
      state.player=null;state.lastTime=null;state.paused=false;pause.textContent='⏸ Pause';
      canvas.style.background='#000';status.textContent='Opening recording…';
      // Allow the recorder to release the previous playback connection.
      await wait(500);
      if(state.closed||token!==generation||request!==state.request)return;
      let Player;
      try{Player=window.requirejs('WasmPlayer/wasm-player');}catch(e){status.textContent='Player unavailable';return;}
      try{
        const player=new Player({type:'record',canvas,
          onsuccess:()=>{if(!state.closed&&request===state.request)status.textContent='Playback connected — waiting for frames…';},
          ontime:value=>{
            if(state.closed||request!==state.request)return;
            const n=Number(value);state.lastTime=Number.isFinite(n)?(n>1e12?n/1000:n):null;
            status.textContent='Playback time: '+formatRecordingTime(value);
            const clip=state.clip;
            if(clip?.started&&state.lastTime>=clip.end&&!clip.finished){
              clip.finished=true;clearTimeout(clip.timeout);
              try{clip.recorder.stop();}catch(e){clipInfo.textContent='Could not finish clip: '+e.message;cancelClip();}
            }
            updateTimeline(value);
          },
          onerror:e=>{if(!state.closed&&request===state.request){status.textContent='Playback error — recording may be unavailable.';console.warn('SBC playback',e);}}
        });
        state.player=player;
        for(let i=0;i<70&&!player.wasmReady&&!state.closed&&request===state.request;i++)await wait(100);
        if(state.closed||token!==generation||request!==state.request)return;
        if(!player.wasmReady){status.textContent='Playback decoder unavailable';return;}
        player.play({chlID:channelID,chlName:settings.names[ch]||DEFAULT_NAMES[ch]||`Camera ${ch}`,startTime:start,endTime:end,streamType:1,winIndex:0,showWatermark:false});
        if(speed.value!=='1')try{player.setSpeed(Number(speed.value));}catch(e){console.warn('Playback speed',e);}
      }catch(e){status.textContent='Unable to start playback: '+e.message;console.warn(e);}
    }
    async function startLive(){
      if(state.closed||!root||token!==generation)return;
      const request=++state.request;
      try{state.player?.destroy();}catch(e){console.warn('SBC camera switch',e);}
      state.player=null;state.paused=false;state.lastTime=null;
      status.textContent='Connecting to live camera…';
      await wait(500);
      if(state.closed||token!==generation||request!==state.request||state.mode!=='live')return;
      try{
        const Player=window.requirejs('WasmPlayer/wasm-player');
        const player=new Player({type:'live',canvas,
          onsuccess:()=>{if(!state.closed&&request===state.request)status.textContent='● LIVE — '+(settings.names[ch]||DEFAULT_NAMES[ch]||`Camera ${ch}`);},
          onerror:e=>{if(!state.closed&&request===state.request){status.textContent='Live connection unavailable';console.warn('SBC live',e);}}
        });
        state.player=player;
        for(let i=0;i<70&&!player.wasmReady&&!state.closed&&request===state.request;i++)await wait(100);
        if(state.closed||token!==generation||request!==state.request||state.mode!=='live')return;
        if(!player.wasmReady){status.textContent='Live decoder unavailable';return;}
        player.play({chlID:channelID,streamType:2,audio:false});
      }catch(e){if(!state.closed&&request===state.request){status.textContent='Unable to start live video: '+e.message;console.warn(e);}}
    }
    function switchMode(mode){
      if(state.clip)cancelClip();
      if(state.closed||state.mode===mode)return;
      state.mode=mode;
      for(const el of playbackElements)el.style.display=mode==='playback'?'':'none';
      liveButton.style.background=mode==='live'?'#80c9ed':'#405565';
      liveButton.style.color=mode==='live'?'#10202d':'white';
      playbackButton.style.background=mode==='playback'?'#80c9ed':'#405565';
      playbackButton.style.color=mode==='playback'?'#10202d':'white';
      if(mode==='live')startLive();
      else{
        const activityPromise=loadActivity();
        if(!state.retentionStarted){
          state.retentionStarted=true;
          activityPromise.finally(()=>{if(!state.closed&&state.mode==='playback')findOldestRecording();});
        }
        startAtSelected();
      }
    }
    // A single viewer and canvas are reused for both player types.
    switchMode(initialMode==='live'?'live':'playback');
  }

  // Group playback deliberately uses its own viewer; single-camera playback is unchanged.
  async function openGroupPlayback(groupIndex){
    const group=settings.groups[groupIndex];
    if(!root||!group?.cameras.length)return;
    stop();
    const token=generation;
    const channels=group.cameras.slice(0,4);
    const overlay=make('div','position:fixed;inset:0;z-index:2147483646;background:#000e;display:flex;align-items:flex-start;justify-content:center;padding:14px;box-sizing:border-box;overflow-y:auto');
    const panel=make('div','width:min(1180px,97vw);max-height:96vh;overflow:auto;background:#172530;border:1px solid #496071;border-radius:12px;padding:15px;box-sizing:border-box;color:#f2f6fa;box-shadow:0 14px 60px #000a');
    const top=make('div','display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:12px');
    top.append(make('strong','font-size:18px',group.name+' — Group Playback'));
    const close=btn('×',()=>closePlayback());close.title='Close group playback';top.append(close);panel.append(top);
    const grid=make('div','display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px');panel.append(grid);
    const tiles=channels.map(ch=>{
      const tile=make('div','min-width:0;background:#050b10;border:1px solid #405363;border-radius:6px;overflow:hidden');
      const label=make('div','padding:7px 10px;background:#263846;font-size:13px',`${settings.names[ch]||DEFAULT_NAMES[ch]||'Camera '+ch} (CH ${ch})`);
      const feed=make('div','position:relative;width:100%;aspect-ratio:16/9;background:#000');
      const canvas=make('canvas','display:block;width:100%;height:100%;background:#000');canvas.width=640;canvas.height=360;
      const status=make('div','font-size:11px;padding:5px 10px;color:#b9d4e5','Waiting for recording…');
      const shortcuts=make('div','position:absolute;left:8px;bottom:8px;z-index:3;display:flex;gap:6px;align-items:center');
      const snap=btn('📷',()=>snapshotCanvas(canvas,ch,tiles.find(t=>t.ch===ch)?.lastTime));
      snap.title='Save snapshot of '+(settings.names[ch]||DEFAULT_NAMES[ch]||'Camera '+ch);
      snap.setAttribute('aria-label',snap.title);
      const saveClip=btn('✂',()=>openGroupClip(ch));
      saveClip.title='Save video clip from '+(settings.names[ch]||DEFAULT_NAMES[ch]||'Camera '+ch);
      saveClip.setAttribute('aria-label',saveClip.title);
      for(const shortcut of [snap,saveClip]){
        shortcut.style.cssText='width:32px;height:30px;padding:0;border:1px solid #7897ab;border-radius:5px;background:#243442e8;color:white;font:18px Arial;line-height:28px;cursor:pointer;box-sizing:border-box';
      }
      shortcuts.append(snap,saveClip);feed.append(canvas,shortcuts);
      tile.append(label,feed,status);grid.append(tile);
      return {ch,canvas,status,player:null,lastTime:null,request:0,records:[],activityStatus:'Loading…'};
    });
    const snapshotAll=btn('📷 Snapshot All',()=>{
      const out=document.createElement('canvas');out.width=1280;out.height=720;
      const ctx=out.getContext('2d');ctx.fillStyle='#071018';ctx.fillRect(0,0,1280,720);
      tiles.forEach((tile,i)=>{const x=(i%2)*640,y=Math.floor(i/2)*360;
        try{ctx.drawImage(tile.canvas,x,y,640,360);}catch(e){console.warn('Snapshot all',e);}
        ctx.fillStyle='#14222edd';ctx.fillRect(x,y,640,27);ctx.fillStyle='#fff';ctx.font='17px Arial';
        ctx.fillText(settings.names[tile.ch]||DEFAULT_NAMES[tile.ch]||'Camera '+tile.ch,x+10,y+19);
      });
      out.toBlob(blob=>{if(blob)downloadBlob(blob,`SunshineBay_Group_${safeFilePart(group.name)}_${Date.now()}.png`);else alert('Unable to capture group snapshot.');},'image/png');
    });
    snapshotAll.style.setProperty('margin-top','8px','important');
    snapshotAll.style.setProperty('margin-bottom','4px','important');
    panel.append(snapshotAll);
    // A single group export panel targets one camera at a time. It records
    // that camera's existing canvas, without opening a fifth DVR connection.
    const groupClipPanel=make('div','background:#20313d;border:1px solid #496071;border-radius:7px;padding:12px;margin:10px 0');
    groupClipPanel.hidden=true;
    const groupClipTitle=make('strong','','Save individual camera clip');
    const groupClipInputs=make('div','display:flex;gap:9px;align-items:center;flex-wrap:wrap;margin:10px 0');
    const groupClipDay=make('input','padding:6px;border-radius:5px');groupClipDay.type='date';
    const groupClipStart=make('input','padding:6px;border-radius:5px');groupClipStart.type='time';groupClipStart.step='1';
    const groupClipEnd=make('input','padding:6px;border-radius:5px');groupClipEnd.type='time';groupClipEnd.step='1';
    groupClipInputs.append(make('span','','Date:'),groupClipDay,make('span','','Start:'),groupClipStart,make('span','','End:'),groupClipEnd);
    const groupClipActions=make('div','display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-top:10px');
    const groupMarkStart=btn('Mark Start',()=>markGroupClip('start'));
    const groupMarkEnd=btn('Mark End',()=>markGroupClip('end'));
    const groupExportButton=btn('⬇ Record & Download Clip',()=>exportGroupClip());
    const groupCancelButton=btn('Cancel',()=>{if(state.clip){cancelGroupClip();groupClipInfo.textContent='Clip recording canceled.';}else groupClipPanel.hidden=true;});
    groupClipActions.append(groupMarkStart,groupMarkEnd,groupExportButton,groupCancelButton);
    for(const button of [groupMarkStart,groupMarkEnd,groupExportButton,groupCancelButton]){
      for(const [property,value] of Object.entries({height:'36px','box-sizing':'border-box',display:'inline-flex','align-items':'center','justify-content':'center',margin:'0',padding:'0 12px','line-height':'1','white-space':'nowrap','flex-shrink':'0'}))button.style.setProperty(property,value,'important');
    }
    const groupClipInfo=make('div','font-size:12px;color:#b9d4e5;margin-top:8px','Note: Saving a clip will move all cameras to the selected start time to keep them synchronized.');
    groupClipPanel.append(groupClipTitle,groupClipInputs,groupClipActions,groupClipInfo);panel.append(groupClipPanel);
    const now=miamiParts(new Date(Date.now()-5*60*1000));
    const controls=make('div','display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin:14px 0 8px');
    const date=make('input','height:35px;box-sizing:border-box;padding:5px;border-radius:5px');date.type='date';date.value=now.day;date.max=now.day;date.min='';
    // All cameras share one DVR recording-history boundary and cache.
    try{
      const history=JSON.parse(localStorage.getItem(RETENTION_CACHE_KEY)||'{}');
      const oldest=history?.[SHARED_RETENTION_ID]?.oldest||history?.['12']?.oldest;
      const valid=day=>typeof day==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(day)&&Number.isFinite(Date.parse(day+'T00:00:00Z'))&&new Date(day+'T00:00:00Z').toISOString().slice(0,10)===day&&day<=now.day;
      if(valid(oldest)){
        date.min=oldest;
        if(date.value<oldest)date.value=oldest;
      }
    }catch(e){console.info('SBC group retention cache unavailable',e);}
    const time=make('input','height:35px;box-sizing:border-box;padding:5px;border-radius:5px');time.type='time';time.value=now.time;time.step=60;
    const play=btn('▶ Play from selected time',()=>seekAll());
    const pause=btn('⏸ Pause',()=>togglePause());
    const back=btn('↶ 30 sec',()=>skip(-30));
    const forward=btn('30 sec ↷',()=>skip(30));
    const speed=make('select','padding:8px;border-radius:5px');
    for(const v of [0.5,1,2,4,8,16,32]){const opt=make('option','',v+'×');opt.value=v;speed.append(opt);}speed.value='1';
    const goLive=btn('● Return to Live Group',()=>closePlayback());
    controls.append(make('span','','Date (Miami):'),date,make('span','margin-left:5px','Time:'),time,play,pause,back,forward,make('span','','Speed:'),speed,goLive);panel.append(controls);
    const status=make('div','font-size:12px;color:#b9d4e5;margin-bottom:10px','Select a date and time for synchronized playback.');panel.append(status);
    const box=make('div','background:#20313d;border:1px solid #496071;border-radius:8px;padding:12px');
    const heading=make('div','display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:8px');
    heading.append(make('strong','font-size:13px','Recording activity by camera'));
    const zoom=make('select','padding:5px;border-radius:5px;margin-left:auto');
    for(const h of [24,12,6,3,1]){const o=make('option','',h===24?'Full day':h+' hour'+(h===1?'':'s'));o.value=h;zoom.append(o);}
    heading.append(make('span','font-size:12px','Zoom:'),zoom);box.append(heading);
    const timelineCanvas=make('canvas','display:block;width:100%;height:auto;background:#263846;border-radius:5px;cursor:pointer;touch-action:pan-y');box.append(timelineCanvas);
    const legend=make('div','display:flex;gap:16px;flex-wrap:wrap;font-size:12px;margin:8px 0;color:#c4d5df');
    legend.append(make('span','color:#0080ff','■ Recording'),make('span','color:#fefc0b','■ Motion'),make('span','','│ Shared playback position'));box.append(legend);
    const motions=make('div','display:flex;gap:8px;flex-wrap:wrap');
    motions.append(btn('← Previous Motion',()=>jumpMotion(-1)),btn('Next Motion →',()=>jumpMotion(1)),btn('Center on playback',()=>{state.center=state.seconds;draw();}));box.append(motions);panel.append(box);
    const help=make('div','font-size:12px;color:#a8c0cf;margin-top:8px','Click a camera’s activity row to seek all cameras. Yellow marks motion; blue marks scheduled recording.');panel.append(help);
    overlay.append(panel);root.append(overlay);
    const state={overlay,closed:false,activityRequest:0,groupPlayers:[],syncTimer:null,seconds:now.seconds,center:now.seconds,anchor:null,paused:false,request:0,clip:null,clipTarget:null};
    playbackDialog=state;
    state.cancelClip=()=>cancelGroupClip();
    // Modal closes only through its explicit X button; backdrop clicks do nothing.
    function openGroupClip(ch){
      if(state.clip){groupClipInfo.textContent='Finish or cancel the current clip before choosing another camera.';groupClipPanel.hidden=false;return;}
      const tile=tiles.find(t=>t.ch===ch);if(!tile)return;
      state.clipTarget=ch;groupClipTitle.textContent=`Save clip — ${settings.names[ch]||DEFAULT_NAMES[ch]||'Camera '+ch} (CH ${ch})`;
      const epoch=Number.isFinite(tile.lastTime)?tile.lastTime:miamiEpoch(date.value,time.value);
      const p=miamiParts(new Date(epoch*1000)),end=miamiParts(new Date((epoch+300)*1000));
      groupClipDay.value=p.day;groupClipStart.value=p.time+':'+String(p.seconds%60).padStart(2,'0');
      // The editor uses a single Miami date, so cap the default at midnight.
      groupClipEnd.value=end.day===p.day?end.time+':'+String(end.seconds%60).padStart(2,'0'):'23:59:59';
      groupClipInfo.textContent='Note: Saving a clip will move all cameras to the selected start time to keep them synchronized.';
      groupClipPanel.hidden=false;
    }
    function markGroupClip(which){
      const tile=tiles.find(t=>t.ch===state.clipTarget);if(!tile)return;
      const epoch=Number.isFinite(tile.lastTime)?tile.lastTime:miamiEpoch(date.value,time.value);
      const p=miamiParts(new Date(epoch*1000));groupClipDay.value=p.day;
      (which==='start'?groupClipStart:groupClipEnd).value=p.time+':'+String(p.seconds%60).padStart(2,'0');
    }
    function cancelGroupClip(){
      const clip=state.clip;if(!clip)return;state.clip=null;
      clearTimeout(clip.timeout);
      try{clip.recorder?.stop();}catch(e){}
      try{clip.stream?.getTracks().forEach(t=>t.stop());}catch(e){}
      groupExportButton.disabled=false;
    }
    async function exportGroupClip(){
      if(state.clip){groupClipInfo.textContent='A clip is already being recorded.';return;}
      if(!window.MediaRecorder){groupClipInfo.textContent='MediaRecorder is unavailable in this browser.';return;}
      const tile=tiles.find(t=>t.ch===state.clipTarget);
      if(!tile||!tile.canvas.captureStream){groupClipInfo.textContent='Select a camera with browser video capture support.';return;}
      const day=groupClipDay.value,startStr=groupClipStart.value,endStr=groupClipEnd.value;
      if(!day||!startStr||!endStr){groupClipInfo.textContent='Enter the date, start time and end time.';return;}
      const start=miamiEpoch(day,startStr)+Number(startStr.split(':')[2]||0);
      const end=miamiEpoch(day,endStr)+Number(endStr.split(':')[2]||0);
      if(!Number.isFinite(start)||!Number.isFinite(end)||end<=start){groupClipInfo.textContent='End time must be later than start time on the selected date.';return;}
      if(end-start>600){groupClipInfo.textContent='Select a clip of 10 minutes or less.';return;}
      if(end>Date.now()/1000){groupClipInfo.textContent='The clip cannot end in the future.';return;}
      const mime=['video/webm;codecs=vp9','video/webm;codecs=vp8','video/webm'].find(x=>MediaRecorder.isTypeSupported(x));
      if(!mime){groupClipInfo.textContent='This browser does not support WebM recording.';return;}
      let clip;
      try{
        groupExportButton.disabled=true;
        const stream=tile.canvas.captureStream(15),recorder=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:2500000});
        clip={tile,start,end,stream,recorder,chunks:[],started:false,finished:false,timeout:null};state.clip=clip;
        recorder.ondataavailable=e=>{if(e.data?.size)clip.chunks.push(e.data);};
        recorder.onerror=e=>{groupClipInfo.textContent='Video encoding failed: '+(e.error?.message||'unknown error');cancelGroupClip();};
        recorder.onstop=()=>{
          try{stream.getTracks().forEach(t=>t.stop());}catch(e){}
          if(state.clip!==clip)return;
          state.clip=null;
          groupExportButton.disabled=false;
          if(!clip.finished){clearTimeout(clip.timeout);groupClipInfo.textContent='Clip export interrupted.';return;}
          if(!clip.chunks.length){groupClipInfo.textContent='No video frames were captured.';return;}
          const file=`SunshineBay_${safeFilePart(settings.names[tile.ch]||DEFAULT_NAMES[tile.ch]||'Camera_'+tile.ch)}_${day}_${startStr.replace(/:/g,'-')}_CH${tile.ch}.webm`;
          downloadBlob(new Blob(clip.chunks,{type:mime}),file);
          groupClipInfo.textContent='Video clip downloaded as WebM (no audio).';
        };
        date.value=day;time.value=startStr.slice(0,5);speed.value='1';
        groupClipInfo.textContent='Seeking all cameras to clip start…';
        clip.timeout=setTimeout(()=>{if(state.clip===clip){groupClipInfo.textContent='Clip timed out waiting for DVR playback.';cancelGroupClip();}},Math.min(900000,(end-start+90)*1000));
        await seekAll(Number(startStr.split(':')[0])*3600+Number(startStr.split(':')[1])*60+Number(startStr.split(':')[2]||0),clip);
      }catch(e){
        if(clip&&state.clip!==clip)return;
        groupClipInfo.textContent='Could not export video: '+e.message;cancelGroupClip();
        groupExportButton.disabled=false;
      }
    }
    function updateGroupClip(tile){
      const clip=state.clip;
      if(!clip||clip.tile!==tile||clip.finished||tile.lastTime<clip.start)return;
      try{
        if(!clip.started){
          if(tile.lastTime>=clip.end){
            groupClipInfo.textContent='No recording frames arrived within the selected interval.';
            cancelGroupClip();
            return;
          }
          // Start as soon as the selected camera reaches the interval, even
          // while the remaining group decoders are still connecting.
          clip.recorder.start(1000);
          clip.started=true;
          groupClipInfo.textContent='Recording selected camera in real time. Keep Group Playback open…';
        }else if(tile.lastTime>=clip.end){
          clip.finished=true;
          clearTimeout(clip.timeout);
          clip.recorder.stop();
        }
      }catch(e){
        groupClipInfo.textContent='Could not record clip: '+e.message;
        cancelGroupClip();
      }
    }
    const secondsLabel=n=>{n=Math.max(0,Math.min(86399,Math.floor(n||0)));return `${String(Math.floor(n/3600)).padStart(2,'0')}:${String(Math.floor(n%3600/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;};
    const channelID=ch=>`{${ch.toString(16).toUpperCase().padStart(8,'0')}-0000-0000-0000-000000000000}`;
    function visible(){const duration=Number(zoom.value)*3600;const start=duration===86400?0:Math.max(0,Math.min(86400-duration,state.center-duration/2));return {start,duration};}
    function draw(){
      if(state.closed)return;
      const w=Math.max(400,Math.round(timelineCanvas.getBoundingClientRect().width||800)),h=tiles.length*38+34;
      const ratio=Math.min(window.devicePixelRatio||1,2);timelineCanvas.width=Math.round(w*ratio);timelineCanvas.height=Math.round(h*ratio);timelineCanvas.style.height=h+'px';
      const ctx=timelineCanvas.getContext('2d');ctx.scale(ratio,ratio);ctx.fillStyle='#263846';ctx.fillRect(0,0,w,h);
      const left=150,right=w-12,plot=Math.max(1,right-left),{start,duration}=visible();
      tiles.forEach((tile,i)=>{
        const y=6+i*38;
        ctx.fillStyle='#e1ebf2';ctx.font='12px sans-serif';ctx.textAlign='left';ctx.fillText(`CH ${tile.ch} · ${tile.activityStatus}`,8,y+16,136);
        ctx.fillStyle='#14232e';ctx.fillRect(left,y,plot,25);
        for(const type of ['SCHEDULE','MOTION']){
          ctx.fillStyle=type==='MOTION'?'#fefc0b':'#0080FF';
          for(const rec of tile.records){if(rec.event!==type||rec.endTime<start||rec.startTime>start+duration)continue;
            const a=left+(Math.max(start,rec.startTime)-start)/duration*plot;
            const b=left+(Math.min(start+duration,rec.endTime)-start)/duration*plot;
            ctx.fillRect(a,y+3,Math.max(1,b-a),19);
          }
        }
      });
      const step=duration>=86400?14400:duration>=43200?7200:duration>=21600?3600:duration>=10800?1800:900;
      ctx.fillStyle='#d2e0e8';ctx.strokeStyle='#8297a5';ctx.font='11px sans-serif';
      for(let t=Math.ceil(start/step)*step;t<=start+duration;t+=step){const x=left+(t-start)/duration*plot;ctx.beginPath();ctx.moveTo(x,h-25);ctx.lineTo(x,h-20);ctx.stroke();ctx.textAlign='center';ctx.fillText(secondsLabel(t).slice(0,5),x,h-7);}
      if(state.seconds>=start&&state.seconds<=start+duration){const x=left+(state.seconds-start)/duration*plot;ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x,2);ctx.lineTo(x,h-27);ctx.stroke();}
    }
    timelineCanvas.onclick=e=>{
      const rect=timelineCanvas.getBoundingClientRect(),x=e.clientX-rect.left;
      const w=rect.width,left=150,right=w-12;if(x<left||x>right)return;
      const {start,duration}=visible();const sec=Math.max(0,Math.min(86399,Math.floor(start+(x-left)/(right-left)*duration)));
      state.anchor=null;state.seconds=sec;state.center=sec;time.value=secondsLabel(sec).slice(0,5);seekAll(sec);
    };
    zoom.onchange=draw;
    function jumpMotion(direction){
      const events=tiles.flatMap(t=>t.records.filter(r=>r.event==='MOTION').map(r=>r.startTime)).sort((a,b)=>a-b);
      const current=state.anchor===null?state.seconds:state.anchor;
      const target=direction>0?events.find(t=>t>current+1):events.filter(t=>t<current-1).pop();
      if(target===undefined){status.textContent=direction>0?'No later motion across this group.':'No earlier motion across this group.';return;}
      state.anchor=target;state.seconds=target;state.center=target;time.value=secondsLabel(target).slice(0,5);seekAll(target);
    }
    async function loadActivity(){
      const request=++state.activityRequest,day=date.value;
      tiles.forEach(t=>{t.records=[];t.activityStatus='Loading…';});draw();
      let Communication;try{Communication=window.requirejs('Communication');}catch(e){status.textContent='DVR recording search unavailable';return;}
      // Query sequentially to avoid overwhelming the recorder.
      for(const tile of tiles){
        if(state.closed||request!==state.activityRequest)return;
        const xml=Communication.GetRequestHeader('queryChlRecLog')+
          '<types><recType><enum>MOTION</enum><enum>SCHEDULE</enum><enum>SENSOR</enum><enum>MANUAL</enum><enum>INTELLIGENT</enum><enum>POS</enum></recType></types>'+
          '<requireField><chl/><recList><item><recType/><startTime/><endTime/><size/></item></recList></requireField>'+
          `<condition><startTime>${day} 00:00:00</startTime><endTime>${day} 23:59:59</endTime>`+
          "<recType type='list'><itemType type='recType'/><item>MOTION</item><item>SCHEDULE</item></recType>"+
          `<chl id='${channelID(tile.ch)}'></chl></condition>`+Communication.GetRequestEnd();
        try{
          const result=await new Promise((resolve,reject)=>Communication.Request({url:'queryChlRecLog',data:xml}).done(resolve).fail(reject));
          if(state.closed||request!==state.activityRequest)return;
          const $=window.jQuery,ok=$('response>status',result).text()==='success';
          if(!ok){tile.activityStatus='Unavailable';draw();continue;}
          const records=[];
          $('response>content>recList>item',result).each(function(){
            const node=$(this),event=node.find('recType').text();if(!['MOTION','SCHEDULE'].includes(event))return;
            const toSec=str=>{const m=String(str).match(/(\d{2}):(\d{2}):(\d{2})/);return m?Number(m[1])*3600+Number(m[2])*60+Number(m[3]):NaN;};
            const a=toSec(node.find('startTime').text()),b=toSec(node.find('endTime').text());
            if(Number.isFinite(a)&&Number.isFinite(b)&&b>=a)records.push({event,startTime:a,endTime:b});
          });
          tile.records=records;tile.activityStatus=records.filter(r=>r.event==='MOTION').length+' motions';
        }catch(e){tile.activityStatus='Unavailable';console.warn('SBC group activity',tile.ch,e);}
        draw();
      }
    }
    function togglePause(){state.paused=!state.paused;pause.textContent=state.paused?'▶ Resume':'⏸ Pause';for(const t of tiles){try{if(state.paused)t.player?.pause();else t.player?.resume();}catch(e){console.warn('Group pause',e);}}}
    function skip(delta){const base=tiles.find(t=>Number.isFinite(t.lastTime))?.lastTime??miamiEpoch(date.value,time.value);const next=new Date((base+delta)*1000),p=miamiParts(next);if(p.day<date.min||p.day>date.max){status.textContent='Outside available date range';return;}const changed=p.day!==date.value;date.value=p.day;time.value=p.time;state.anchor=null;if(changed)loadActivity();seekAll(p.seconds);}
    async function seekAll(exactSeconds=null,exportClip=null){
      if(state.closed||token!==generation)return;
      // Only the seek initiated by this export may keep its capture armed.
      if(state.clip&&state.clip!==exportClip){cancelGroupClip();groupClipInfo.textContent='Clip recording canceled because playback was moved.';}
      if(date.value<date.min||date.value>date.max){
        status.textContent='Date outside available recording range';
        if(exportClip)throw new Error(status.textContent);
        return;
      }
      const sec=exactSeconds===null?Number(time.value.slice(0,2))*3600+Number(time.value.slice(3,5))*60:exactSeconds;
      const start=miamiEpoch(date.value,secondsLabel(sec).slice(0,5))+sec%60;
      const end=miamiEpoch(date.value,'23:59')+59;
      if(!Number.isFinite(start)||start>end){status.textContent='Invalid selected time';return;}
      state.seconds=sec;state.center=sec;state.paused=false;pause.textContent='⏸ Pause';draw();
      const request=++state.request;status.textContent='Starting synchronized recordings…';
      for(const tile of tiles){try{tile.player?.destroy();}catch(e){}tile.player=null;tile.lastTime=null;tile.status.textContent='Connecting…';}
      state.groupPlayers=[];
      await wait(500);if(state.closed||token!==generation||request!==state.request)return;
      let Player;try{Player=window.requirejs('WasmPlayer/wasm-player');}catch(e){
        status.textContent='DVR player unavailable';
        if(state.clip===exportClip&&exportClip)throw new Error(status.textContent);
        return;
      }
      // Stagger decoder initialization to avoid exceeding DVR resource limits.
      for(const tile of tiles){
        if(state.closed||request!==state.request||token!==generation)return;
        try{
          const player=new Player({type:'record',canvas:tile.canvas,
            onsuccess:()=>{if(!state.closed&&request===state.request)tile.status.textContent='Connected — waiting for frames…';},
            ontime:value=>{
              if(state.closed||request!==state.request)return;
              const n=Number(value);if(!Number.isFinite(n))return;
              tile.lastTime=n>1e12?n/1000:n;
              updateGroupClip(tile);
              tile.status.textContent='Playback: '+formatRecordingTime(value);
              // Use the first reporting camera as the shared display clock.
              const reference=tiles.find(t=>Number.isFinite(t.lastTime));
              if(reference===tile){const p=miamiParts(new Date(tile.lastTime*1000));if(p.day===date.value){state.seconds=p.seconds;draw();}}
            },
            onerror:e=>{if(!state.closed&&request===state.request){tile.status.textContent='Recording unavailable / playback error';console.warn('SBC group playback',tile.ch,e);}}
          });
          tile.player=player;state.groupPlayers.push(player);
          for(let i=0;i<70&&!player.wasmReady&&!state.closed&&request===state.request;i++)await wait(100);
          if(state.closed||request!==state.request||token!==generation)return;
          if(!player.wasmReady){tile.status.textContent='Decoder unavailable';continue;}
          player.play({chlID:channelID(tile.ch),chlName:settings.names[tile.ch]||DEFAULT_NAMES[tile.ch]||`Camera ${tile.ch}`,startTime:start,endTime:end,streamType:1,winIndex:0,showWatermark:false});
          if(speed.value!=='1')try{player.setSpeed(Number(speed.value));}catch(e){}
        }catch(e){tile.status.textContent='Could not open recording';console.warn('SBC group stream',tile.ch,e);}
        await wait(200);
      }
      if(!state.closed&&request===state.request)status.textContent='Group playback running · individual cameras may have recording gaps.';
    }
    // Reconcile independent DVR clocks when a supported seek() operation is available.
    state.syncTimer=setInterval(()=>{
      if(state.closed||state.paused)return;
      const ref=state.clip?.tile||tiles.find(t=>Number.isFinite(t.lastTime));if(!ref||!Number.isFinite(ref.lastTime))return;
      for(const tile of tiles){if(tile===ref||!Number.isFinite(tile.lastTime)||!tile.player)continue;
        if(Math.abs(tile.lastTime-ref.lastTime)>3){try{if(typeof tile.player.seek==='function')tile.player.seek(ref.lastTime);}catch(e){console.warn('SBC group sync',tile.ch,e);}}
      }
    },3000);
    speed.onchange=()=>{for(const tile of tiles)try{tile.player?.setSpeed(Number(speed.value));}catch(e){console.warn('Group speed',e);}};
    date.onchange=()=>{state.anchor=null;loadActivity();};
    if(window.ResizeObserver){const observer=new ResizeObserver(draw);observer.observe(timelineCanvas);state.activityObserver=observer;}
    draw();loadActivity();seekAll();
  }

  function showManager(){managing=true;stop();drawActions();drawTabs();content.replaceChildren();const top=make('div','display:flex;justify-content:space-between;align-items:center;margin-bottom:12px');top.append(make('h3','margin:0','Groups'));
    const groupButtons=make('div','display:flex;flex-wrap:wrap;gap:8px;justify-content:flex-end');
    const restore=btn('Restore Default Groups',()=>{
      if(!confirm('Restore the four default groups (Garage, Entries, Upper Floors, Trash/Camera Rooms)? This replaces your current groups and camera assignments, but keeps your custom camera names and All Cameras order.'))return;
      settings.groups=defaults.groups.map(g=>({name:g.name,cameras:[...g.cameras]}));
      active=0;
      save();saveView();showManager();
    });
    restore.title='Replace your current groups with the original Sunshine Bay groups';
    groupButtons.append(restore,btn('+ Add Group',()=>{settings.groups.push({name:`Group ${settings.groups.length+1}`,cameras:[]});save();showManager();}));
    top.append(groupButtons);content.append(top);const cards=make('div','display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-bottom:24px');content.append(cards);settings.groups.forEach((g,i)=>{const card=make('div','background:#1d2d39;border:1px solid #405363;border-radius:8px;padding:14px');const row=make('div','display:flex;justify-content:space-between;gap:5px;align-items:center;margin-bottom:8px');row.append(make('strong','',`Group ${i+1}`));const controls=make('div','display:flex;gap:4px');for(const [text,fn] of [['←',()=>{if(i){[settings.groups[i-1],settings.groups[i]]=[settings.groups[i],settings.groups[i-1]];save();showManager();}}],['→',()=>{if(i<settings.groups.length-1){[settings.groups[i+1],settings.groups[i]]=[settings.groups[i],settings.groups[i+1]];save();showManager();}}],['×',()=>{if(settings.groups.length===1)return alert('At least one group must remain.');if(!confirm(`Delete ${g.name}?`))return;settings.groups.splice(i,1);active=Math.min(active,settings.groups.length-1);save();showManager();}]] ){const b=btn(text,fn);b.style.padding='4px 8px';controls.append(b);}row.append(controls);const input=make('input','width:100%;box-sizing:border-box;padding:9px;border-radius:5px');input.value=g.name;input.maxLength=40;input.oninput=()=>{g.name=input.value;save();content.querySelectorAll(`[data-group-label="${i}"]`).forEach(n=>n.textContent=g.name||`Group ${i+1}`);};card.append(row,input,make('div','color:#a9bfcb;margin-top:8px;font-size:12px',`${g.cameras.length} of 4 cameras`));cards.append(card);});content.append(make('h3','margin:0 0 12px','Camera names and assignments'));const table=make('div','background:#1d2d39;border:1px solid #405363;border-radius:8px');CHANNELS.forEach(ch=>{const row=make('div','display:grid;grid-template-columns:65px minmax(120px,1fr) minmax(180px,2fr);gap:12px;align-items:center;padding:12px;border-bottom:1px solid #405363');row.append(make('strong','',`CH ${ch}`));const input=make('input','width:100%;box-sizing:border-box;padding:9px;border-radius:5px');input.value=settings.names[ch]||DEFAULT_NAMES[ch]||`Camera ${ch}`;input.maxLength=60;input.oninput=()=>{settings.names[ch]=input.value;save();};const assignments=make('div','display:flex;flex-wrap:wrap;gap:10px 14px');settings.groups.forEach((g,i)=>{const lab=make('label','display:inline-flex;align-items:center;gap:5px;cursor:pointer');const cb=document.createElement('input');cb.type='checkbox';cb.checked=g.cameras.includes(ch);const txt=make('span','',g.name||`Group ${i+1}`);txt.dataset.groupLabel=i;cb.onchange=()=>{if(cb.checked){if(g.cameras.length>=4){cb.checked=false;alert('Maximum four cameras per group.');return;}if(!g.cameras.includes(ch))g.cameras.push(ch);}else g.cameras=g.cameras.filter(x=>x!==ch);save();showManager();};lab.append(cb,txt);assignments.append(lab);});row.append(input,assignments);table.append(row);});content.append(table);}
  function ready(){try{return !!(window.requirejs&&window.requirejs.defined('WasmPlayer/wasm-player')&&document.body);}catch{return false;}}
  // Do not cover the sign-in page. User can toggle after successful sign-in.
  function looksSignedIn(){const text=(document.body?.innerText||'').slice(0,3000);return !(/password/i.test(location.pathname)&&/login/i.test(text));}
  const poll=setInterval(()=>{if(ready()&&looksSignedIn()){clearInterval(poll);if(!document.body.contains(toggle))document.body.append(toggle);open();}},1000);
  window.addEventListener('pagehide',()=>clearInterval(poll),{once:true});
  window.sunshineBayExtension={open,hide,settings};
})();
